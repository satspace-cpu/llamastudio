using Hermass.Core.Interfaces;
using System.Collections.Generic;

namespace Hermass.Core.Services;

public class LocalizationService : ILocalizationService
{
    string _language = "ru";

    public string Language
    {
        get => _language;
        set => ChangeLanguage(value);
    }

    readonly Dictionary<string, Dictionary<string, string>> _translations = new()
    {
        // Main window
        ["main.dashboard"] = new() { ["en"] = "Dashboard", ["ru"] = "Главная" },
        ["main.models"] = new() { ["en"] = "Models", ["ru"] = "Модели" },
        ["main.server"] = new() { ["en"] = "Server", ["ru"] = "Сервер" },
        ["main.profiles"] = new() { ["en"] = "Profiles", ["ru"] = "Профили" },
        ["main.logs"] = new() { ["en"] = "Logs", ["ru"] = "Логи" },
        ["main.settings"] = new() { ["en"] = "Settings", ["ru"] = "Настройки" },
        ["main.start_server"] = new() { ["en"] = "Start Server", ["ru"] = "Запустить сервер" },
        ["main.stop_server"] = new() { ["en"] = "Stop Server", ["ru"] = "Остановить сервер" },
        ["main.subtitle"] = new() { ["en"] = " — llama.cpp Manager", ["ru"] = " — менеджер llama.cpp" },

        // Dashboard
        ["dash.title"] = new() { ["en"] = "Dashboard", ["ru"] = "Главная" },
        ["dash.server_label"] = new() { ["en"] = "Server", ["ru"] = "Сервер" },
        ["dash.uptime"] = new() { ["en"] = "Uptime: {0}", ["ru"] = "Работает: {0}" },
        ["dash.models_card"] = new() { ["en"] = "Models", ["ru"] = "Модели" },
        ["dash.indexed"] = new() { ["en"] = "Indexed", ["ru"] = "Найдено" },
        ["dash.profiles_card"] = new() { ["en"] = "Profiles", ["ru"] = "Профили" },
        ["dash.saved"] = new() { ["en"] = "Saved", ["ru"] = "Сохранено" },
        ["dash.llama_cpp"] = new() { ["en"] = "llama.cpp", ["ru"] = "llama.cpp" },
        ["dash.active"] = new() { ["en"] = "Active", ["ru"] = "Активна" },
        ["dash.vram_usage"] = new() { ["en"] = "VRAM Usage", ["ru"] = "Использование VRAM" },
        ["dash.gpu_memory"] = new() { ["en"] = "GPU Memory", ["ru"] = "Память GPU" },
        ["dash.active_model"] = new() { ["en"] = "Active Model", ["ru"] = "Активная модель" },
        ["dash.quick_actions"] = new() { ["en"] = "Quick Actions", ["ru"] = "Быстрые действия" },
        ["dash.scan_models"] = new() { ["en"] = "Scan Models", ["ru"] = "Сканировать модели" },
        ["dash.discover_gguf"] = new() { ["en"] = "Discover GGUF files", ["ru"] = "Найти файлы GGUF" },
        ["dash.create_profile"] = new() { ["en"] = "Create Profile", ["ru"] = "Создать профиль" },
        ["dash.launch_config"] = new() { ["en"] = "Launch config", ["ru"] = "Конфиг запуска" },
        ["dash.check_updates"] = new() { ["en"] = "Check Updates", ["ru"] = "Проверить обновления" },
        ["dash.llama_version"] = new() { ["en"] = "llama.cpp version", ["ru"] = "Версия llama.cpp" },

        // Models page
        ["models.title"] = new() { ["en"] = "Models", ["ru"] = "Модели" },
        ["models.count"] = new() { ["en"] = "models", ["ru"] = "моделей" },
        ["models.scan"] = new() { ["en"] = "Scan Models", ["ru"] = "Сканировать" },
        ["models.scanning"] = new() { ["en"] = "Scanning...", ["ru"] = "Сканирование..." },
        ["models.browse"] = new() { ["en"] = "Browse...", ["ru"] = "Обзор..." },
        ["models.search"] = new() { ["en"] = "Search models...", ["ru"] = "Поиск моделей..." },
        ["models.no_models"] = new() { ["en"] = "No models found. Set a models directory and click Scan.", ["ru"] = "Модели не найдены. Укажите папку и нажмите Сканировать." },
        ["models.use_default_profile"] = new() { ["en"] = "Use in Default Profile", ["ru"] = "В профиль по умолчанию" },
        ["models.to_server"] = new() { ["en"] = "→ Server Model", ["ru"] = "→ Модель сервера" },
        ["models.to_mmproj"] = new() { ["en"] = "→ Server mmproj", ["ru"] = "→ Сервер mmproj" },
        ["models.to_draft"] = new() { ["en"] = "→ Server Draft", ["ru"] = "→ Черновик сервера" },

        // Profiles page
        ["profiles.title"] = new() { ["en"] = "Launch Profiles", ["ru"] = "Профили запуска" },
        ["profiles.new"] = new() { ["en"] = "+ New Profile", ["ru"] = "+ Новый профиль" },
        ["profiles.import"] = new() { ["en"] = "Import JSON", ["ru"] = "Импорт JSON" },
        ["profiles.name_placeholder"] = new() { ["en"] = "Profile name...", ["ru"] = "Имя профиля..." },
        ["profiles.desc_placeholder"] = new() { ["en"] = "Description...", ["ru"] = "Описание..." },
        ["profiles.select_model"] = new() { ["en"] = "Select Model...", ["ru"] = "Выбрать модель..." },
        ["profiles.default_badge"] = new() { ["en"] = "DEFAULT", ["ru"] = "ПО УМОЛЧАНИЮ" },
        ["profiles.set_default"] = new() { ["en"] = "Set Default", ["ru"] = "По умолчанию" },
        ["profiles.edit"] = new() { ["en"] = "Edit", ["ru"] = "Изменить" },
        ["profiles.duplicate"] = new() { ["en"] = "Duplicate", ["ru"] = "Дублировать" },
        ["profiles.export"] = new() { ["en"] = "Export", ["ru"] = "Экспорт" },
        ["profiles.delete"] = new() { ["en"] = "Delete", ["ru"] = "Удалить" },
        ["profiles.save_settings"] = new() { ["en"] = "Save Settings", ["ru"] = "Сохранить настройки" },
        ["profiles.start_server"] = new() { ["en"] = "Start Server", ["ru"] = "Запустить сервер" },

        // Settings page
        ["settings.title"] = new() { ["en"] = "Settings", ["ru"] = "Настройки" },
        ["settings.general_section"] = new() { ["en"] = "General", ["ru"] = "Общие" },
        ["settings.paths_section"] = new() { ["en"] = "Paths", ["ru"] = "Пути" },
        ["settings.llama_cpp_dir_label"] = new() { ["en"] = "llama.cpp:", ["ru"] = "llama.cpp:" },
        ["settings.models_dir_label"] = new() { ["en"] = "Models:", ["ru"] = "Модели:" },
        ["settings.browse_btn"] = new() { ["en"] = "Browse...", ["ru"] = "Обзор..." },
        ["settings.auto_check_updates"] = new() { ["en"] = "Auto-check updates", ["ru"] = "Автопроверка обновлений" },
        ["settings.portable_mode"] = new() { ["en"] = "Portable mode", ["ru"] = "Портативный режим" },
        ["settings.theme_label"] = new() { ["en"] = "Theme:", ["ru"] = "Тема:" },
        ["settings.dark"] = new() { ["en"] = "Dark", ["ru"] = "Тёмная" },
        ["settings.light"] = new() { ["en"] = "Light", ["ru"] = "Светлая" },
        ["settings.system"] = new() { ["en"] = "System", ["ru"] = "Системная" },
        ["settings.active_version"] = new() { ["en"] = "Active version:", ["ru"] = "Активная версия:" },
        ["settings.update_channel_label"] = new() { ["en"] = "Update channel:", ["ru"] = "Канал обновлений:" },
        ["settings.stable"] = new() { ["en"] = "Stable", ["ru"] = "Стабильная" },
        ["settings.prerelease"] = new() { ["en"] = "PreRelease", ["ru"] = "Предварительная" },
        ["settings.nightly"] = new() { ["en"] = "Nightly", ["ru"] = "Ночная сборка" },
        ["settings.server_defaults_section"] = new() { ["en"] = "Server Defaults", ["ru"] = "Параметры сервера по умолчанию" },
        ["settings.host_label"] = new() { ["en"] = "Default host:", ["ru"] = "Хост по умолч.:" },
        ["settings.port_label"] = new() { ["en"] = "Default port:", ["ru"] = "Порт по умолч.:" },
        ["settings.gpu_layers_label"] = new() { ["en"] = "Default GPU layers:", ["ru"] = "Слои GPU по умолч.:" },
        ["settings.flash_attention"] = new() { ["en"] = "Enable Flash Attention by default", ["ru"] = "Flash Attention по умолчанию" },
        ["settings.releases"] = new() { ["en"] = "llama.cpp Releases", ["ru"] = "Релизы llama.cpp" },
        ["settings.check_updates_btn"] = new() { ["en"] = "Check for Updates", ["ru"] = "Проверить обновления" },
        ["settings.checking_status"] = new() { ["en"] = "Checking...", ["ru"] = "Проверка..." },
        ["settings.download"] = new() { ["en"] = "Download", ["ru"] = "Скачать" },
        ["settings.save_settings_btn"] = new() { ["en"] = "Save Settings", ["ru"] = "Сохранить настройки" },
        ["settings.published"] = new() { ["en"] = "Published: {0}", ["ru"] = "Дата: {0}" },
        ["settings.language_label"] = new() { ["en"] = "Language:", ["ru"] = "Язык:" },
        ["settings.russian"] = new() { ["en"] = "Русский", ["ru"] = "Русский" },
        ["settings.english"] = new() { ["en"] = "English", ["ru"] = "English" },

        // Logs page
        ["logs.title"] = new() { ["en"] = "Logs", ["ru"] = "Логи" },
        ["logs.entries"] = new() { ["en"] = "entries", ["ru"] = "записей" },
        ["logs.search_placeholder"] = new() { ["en"] = "Filter...", ["ru"] = "Фильтр..." },
        ["logs.min_level_label"] = new() { ["en"] = "Min level:", ["ru"] = "Уровень:" },
        ["logs.export_btn"] = new() { ["en"] = "Export", ["ru"] = "Экспорт" },
        ["logs.clear_btn"] = new() { ["en"] = "Clear", ["ru"] = "Очистить" },

        // Server page — title & buttons
        ["server.title"] = new() { ["en"] = "Server", ["ru"] = "Сервер" },
        ["server.start_btn"] = new() { ["en"] = "Start", ["ru"] = "Запустить" },
        ["server.stop_btn"] = new() { ["en"] = "Stop", ["ru"] = "Остановить" },
        ["server.health_check_btn"] = new() { ["en"] = "Health Check", ["ru"] = "Проверка" },
        ["server.save_profile_btn"] = new() { ["en"] = "Save to Profile", ["ru"] = "Сохранить в профиль" },
    ["server.load_profile_btn"] = new() { ["en"] = "Load Profile", ["ru"] = "Загрузить" },
    ["server.create_profile_btn"] = new() { ["en"] = "New Profile", ["ru"] = "Создать" },
    ["server.delete_profile_btn"] = new() { ["en"] = "Delete", ["ru"] = "Удалить" },
    ["server.rename_profile_btn"] = new() { ["en"] = "Rename", ["ru"] = "Переименовать" },
    ["server.clear_profile_btn"] = new() { ["en"] = "Clear", ["ru"] = "Очистить" },
    ["server.export_profile_btn"] = new() { ["en"] = "Export", ["ru"] = "Экспорт" },
    ["server.import_profile_btn"] = new() { ["en"] = "Import", ["ru"] = "Импорт" },
    ["server.refresh_profiles_btn"] = new() { ["en"] = "Refresh Profiles", ["ru"] = "Обновить профили" },
        ["server.export_bat_btn"] = new() { ["en"] = "Export .bat", ["ru"] = "Экспорт .bat" },
        ["server.copy_cmdline_btn"] = new() { ["en"] = "Copy CmdLine", ["ru"] = "Копировать команду" },
        ["server.no_profile_selected"] = new() { ["en"] = "No profile selected", ["ru"] = "Профиль не выбран" },
        ["server.no_model_selected"] = new() { ["en"] = "No model selected", ["ru"] = "Модель не выбрана" },
        ["server.browse_model_btn"] = new() { ["en"] = "Browse...", ["ru"] = "Обзор..." },
        ["server.browse_mmproj_btn"] = new() { ["en"] = "Browse...", ["ru"] = "Обзор..." },
        ["server.browse_draft_btn"] = new() { ["en"] = "Browse...", ["ru"] = "Обзор..." },
        ["server.quick_scan_btn"] = new() { ["en"] = "Scan Models Dir", ["ru"] = "Сканировать папку" },
        ["server.quick_select_model_btn"] = new() { ["en"] = "Select Model", ["ru"] = "Выбрать модель" },
        ["server.quick_select_mmproj_btn"] = new() { ["en"] = "Select mmproj", ["ru"] = "Выбрать mmproj" },
        ["server.quick_select_draft_btn"] = new() { ["en"] = "Select Draft", ["ru"] = "Выбрать черновик" },
        ["server.check_version_btn"] = new() { ["en"] = "Check Version", ["ru"] = "Проверить версию" },
        ["server.select_llama_dir_btn"] = new() { ["en"] = "Select Directory...", ["ru"] = "Выбрать папку..." },

        // Server page — Model tab
        ["server.state_label"] = new() { ["en"] = "State:", ["ru"] = "Состояние:" },
        ["server.uptime_fmt"] = new() { ["en"] = "Uptime: {0}", ["ru"] = "Работает: {0}" },
        ["server.vram_fmt"] = new() { ["en"] = "VRAM: {0:F1} GB", ["ru"] = "VRAM: {0:F1} ГБ" },
        ["server.ram_fmt"] = new() { ["en"] = "RAM: {0:F1} GB", ["ru"] = "ОЗУ: {0:F1} ГБ" },
        ["server.tps_fmt"] = new() { ["en"] = "TPS: {0:F1}", ["ru"] = "ток/с: {0:F1}" },
        ["server.health_check"] = new() { ["en"] = "Health Check", ["ru"] = "Проверка" },
        ["server.tab_model"] = new() { ["en"] = "Model", ["ru"] = "Модель" },
        ["server.server_path_title"] = new() { ["en"] = "llama.cpp Server Path", ["ru"] = "Путь к llama.cpp серверу" },
        ["server.browse"] = new() { ["en"] = "Browse", ["ru"] = "Обзор" },
        ["server.exec_hint"] = new() { ["en"] = "Server executable will be: llama-server.exe in this folder. Download llama.cpp build and extract here.", ["ru"] = "Исполняемый файл сервера: llama-server.exe в этой папке. Скачайте сборку llama.cpp и распакуйте сюда." },
        ["server.exec_found_fmt"] = new() { ["en"] = "Executable found: {0}", ["ru"] = "Файл найден: {0}" },
        ["server.check_version"] = new() { ["en"] = "Check Version", ["ru"] = "Проверить версию" },
        ["server.main_model"] = new() { ["en"] = "Main Model", ["ru"] = "Основная модель" },
        ["server.model_watermark"] = new() { ["en"] = "Path to .gguf model file", ["ru"] = "Путь к файлу модели .gguf" },
        ["server.mmproj_title"] = new() { ["en"] = "mmproj (Vision)", ["ru"] = "mmproj (Зрение)" },
        ["server.optional"] = new() { ["en"] = "Optional", ["ru"] = "Необязательно" },
        ["server.mmproj_watermark"] = new() { ["en"] = "Path to mmproj .gguf file", ["ru"] = "Путь к файлу mmproj .gguf" },
        ["server.draft_title"] = new() { ["en"] = "Draft Model (Speculative Decoding)", ["ru"] = "Черновая модель (Спекулятивное декодирование)" },
        ["server.advanced_badge"] = new() { ["en"] = "Advanced", ["ru"] = "Продвинуто" },
        ["server.enable_speculative"] = new() { ["en"] = "Enable Speculative Decoding", ["ru"] = "Включить спекулятивное декодирование" },
        ["server.draft_watermark"] = new() { ["en"] = "Path to draft .gguf model", ["ru"] = "Путь к черновой модели .gguf" },
        ["server.quick_select_title"] = new() { ["en"] = "Quick Model Selection (Local)", ["ru"] = "Быстрый выбор модели (локально)" },
        ["server.scan_models_dir"] = new() { ["en"] = "Scan Models Directory", ["ru"] = "Сканировать папку моделей" },
        ["server.to_main"] = new() { ["en"] = "→ Main Model", ["ru"] = "→ Основная модель" },
        ["server.to_mmproj_btn"] = new() { ["en"] = "→ mmproj", ["ru"] = "→ mmproj" },
        ["server.to_draft_btn"] = new() { ["en"] = "→ Draft", ["ru"] = "→ Черновик" },
        ["server.hf_title"] = new() { ["en"] = "HuggingFace — Recommended Models", ["ru"] = "HuggingFace — Рекомендуемые модели" },
        ["server.download_to_fmt"] = new() { ["en"] = "Models will be downloaded to:", ["ru"] = "Модели будут скачаны в:" },
        ["server.select_this_model"] = new() { ["en"] = "Select This Model", ["ru"] = "Выбрать эту модель" },
        ["server.or_manual"] = new() { ["en"] = "Or enter manually:", ["ru"] = "Или ввести вручную:" },
        ["server.repo_label"] = new() { ["en"] = "Repo:", ["ru"] = "Репозиторий:" },
        ["server.offline_mode"] = new() { ["en"] = "Offline mode", ["ru"] = "Офлайн режим" },

        // Server page — GPU tab
        ["server.tab_gpu"] = new() { ["en"] = "GPU", ["ru"] = "GPU" },
        ["server.gpu_acceleration"] = new() { ["en"] = "GPU Acceleration", ["ru"] = "Ускорение GPU" },
        ["server.gpu_layers_label"] = new() { ["en"] = "GPU Layers:", ["ru"] = "Слои GPU:" },
        ["server.threads_label"] = new() { ["en"] = "Threads:", ["ru"] = "Потоки:" },
        ["server.threads_batch_label"] = new() { ["en"] = "Threads Batch:", ["ru"] = "Потоков в батче:" },
        ["server.main_gpu_label"] = new() { ["en"] = "Main GPU:", ["ru"] = "Основной GPU:" },
        ["server.flash_attention"] = new() { ["en"] = "Flash Attention", ["ru"] = "Flash Attention" },
        ["server.memory_map"] = new() { ["en"] = "Memory Map", ["ru"] = "Карта памяти" },
        ["server.mlock"] = new() { ["en"] = "Mlock", ["ru"] = "Mlock" },
        ["server.no_mmq"] = new() { ["en"] = "No MMQ", ["ru"] = "Без MMQ" },
        ["server.no_kv_offload"] = new() { ["en"] = "No KV Offload", ["ru"] = "Без разгрузки KV" },

        // Server page — Context & Sampling tab
        ["server.tab_context_sampling"] = new() { ["en"] = "Context & Sampling", ["ru"] = "Контекст и сэмплинг" },
        ["server.context_batch"] = new() { ["en"] = "Context & Batch", ["ru"] = "Контекст и батч" },
        ["server.context_label"] = new() { ["en"] = "Context:", ["ru"] = "Контекст:" },
        ["server.batch_label"] = new() { ["en"] = "Batch:", ["ru"] = "Батч:" },
        ["server.ubatch_label"] = new() { ["en"] = "U-Batch:", ["ru"] = "U-батч:" },
        ["server.max_tokens_label"] = new() { ["en"] = "Max Tokens:", ["ru"] = "Макс токенов:" },
        ["server.sampling_title"] = new() { ["en"] = "Sampling", ["ru"] = "Сэмплинг" },
        ["server.temperature_label"] = new() { ["en"] = "Temperature:", ["ru"] = "Температура:" },
        ["server.top_p_label"] = new() { ["en"] = "Top-P:", ["ru"] = "Top-P:" },
        ["server.top_k_label"] = new() { ["en"] = "Top-K:", ["ru"] = "Top-K:" },
        ["server.min_p_label"] = new() { ["en"] = "Min-P:", ["ru"] = "Min-P:" },
        ["server.typical_p_label"] = new() { ["en"] = "Typical-P:", ["ru"] = "Typical-P:" },
        ["server.repeat_penalty_label"] = new() { ["en"] = "Repeat Penalty:", ["ru"] = "Штраф повторов:" },
        ["server.repeat_last_n_label"] = new() { ["en"] = "Repeat Last N:", ["ru"] = "Повтор. последних N:" },
        ["server.presence_penalty_label"] = new() { ["en"] = "Presence Penalty:", ["ru"] = "Штраф присутствия:" },
        ["server.frequency_penalty_label"] = new() { ["en"] = "Frequency Penalty:", ["ru"] = "Штраф частоты:" },
        ["server.seed_label"] = new() { ["en"] = "Seed:", ["ru"] = "Сид:" },
        ["server.mirostat_sampling"] = new() { ["en"] = "Mirostat Sampling", ["ru"] = "Mirostat сэмплинг" },
        ["server.tau_label"] = new() { ["en"] = "Tau:", ["ru"] = "Тау:" },
        ["server.eta_label"] = new() { ["en"] = "Eta:", ["ru"] = "Эта:" },

        // Server page — Advanced tab
        ["server.tab_advanced"] = new() { ["en"] = "Advanced", ["ru"] = "Продвинутое" },
        ["server.mtp_title"] = new() { ["en"] = "MTP / Multi-Token Prediction", ["ru"] = "MTP / Много-токенное предсказание" },
        ["server.enable_mtp"] = new() { ["en"] = "Enable MTP", ["ru"] = "Включить MTP" },
        ["server.predict_count_label"] = new() { ["en"] = "Predict Count:", ["ru"] = "Кол-во предсказаний:" },
        ["server.spec_draft_params"] = new() { ["en"] = "Speculative Draft Parameters", ["ru"] = "Параметры спекулятивного черновика" },
        ["server.draft_gpu_layers_label"] = new() { ["en"] = "Draft GPU Layers:", ["ru"] = "Слои GPU черновика:" },
        ["server.draft_n_max_label"] = new() { ["en"] = "Draft N Max:", ["ru"] = "Черновик N макс:" },
        ["server.draft_n_min_label"] = new() { ["en"] = "Draft N Min:", ["ru"] = "Черновик N мин:" },
        ["server.draft_p_split_label"] = new() { ["en"] = "Draft P Split:", ["ru"] = "Черновик P разд.:" },
        ["server.draft_p_min_label"] = new() { ["en"] = "Draft P Min:", ["ru"] = "Черновик P мин:" },
        ["server.yarn_rope_title"] = new() { ["en"] = "YARN / Rope Scaling", ["ru"] = "YARN / Масштабирование Rope" },
        ["server.rope_freq_base_label"] = new() { ["en"] = "Rope Freq Base:", ["ru"] = "Частота Rope база:" },
        ["server.rope_freq_scale_label"] = new() { ["en"] = "Rope Freq Scale:", ["ru"] = "Масштаб частоты Rope:" },
        ["server.yarn_orig_ctx_label"] = new() { ["en"] = "Yarn Orig Ctx:", ["ru"] = "Исх. контекст Yarn:" },
        ["server.advanced_options_title"] = new() { ["en"] = "Advanced Options", ["ru"] = "Дополнительные опции" },
        ["server.numa"] = new() { ["en"] = "NUMA", ["ru"] = "NUMA" },
        ["server.cache_prompt"] = new() { ["en"] = "Cache Prompt", ["ru"] = "Кэш промпта" },
        ["server.cont_batching"] = new() { ["en"] = "Cont. Batching", ["ru"] = "Непрерывный батч" },
        ["server.verbose_logging"] = new() { ["en"] = "Verbose Logging", ["ru"] = "Подробные логи" },
        ["server.web_ui"] = new() { ["en"] = "Web UI", ["ru"] = "Веб-интерфейс" },
        ["server.metrics"] = new() { ["en"] = "Metrics", ["ru"] = "Метрики" },
        ["server.reasoning"] = new() { ["en"] = "Reasoning", ["ru"] = "Рассуждения" },
        ["server.embedding_mode"] = new() { ["en"] = "Embedding Mode", ["ru"] = "Режим эмбеддинга" },
        ["server.custom_args_title"] = new() { ["en"] = "Custom Arguments", ["ru"] = "Пользовательские аргументы" },
        ["server.custom_args_placeholder"] = new() { ["en"] = "Additional command-line arguments...", ["ru"] = "Дополнительные аргументы командной строки..." },
        ["server.export_title"] = new() { ["en"] = "Export", ["ru"] = "Экспорт" },
        ["server.export_bat"] = new() { ["en"] = "Export as .bat", ["ru"] = "Экспорт в .bat" },
        ["server.copy_cmdline"] = new() { ["en"] = "Copy Command Line", ["ru"] = "Копировать команду" },

        // Server page — Connection tab
        ["server.tab_connection"] = new() { ["en"] = "Connection", ["ru"] = "Подключение" },
        ["server.connection_settings"] = new() { ["en"] = "Connection Settings", ["ru"] = "Настройки подключения" },
        ["server.host_label"] = new() { ["en"] = "Host:", ["ru"] = "Хост:" },
        ["server.port_label"] = new() { ["en"] = "Port:", ["ru"] = "Порт:" },
        ["server.timeout_label"] = new() { ["en"] = "Timeout:", ["ru"] = "Таймаут:" },
        ["server.slots_label"] = new() { ["en"] = "Slots:", ["ru"] = "Слоты:" },
        ["server.profile_controls"] = new() { ["en"] = "Profile & Controls", ["ru"] = "Профиль и управление" },
        ["server.refresh_profiles"] = new() { ["en"] = "Refresh", ["ru"] = "Обновить" },
        ["server.start_server_btn"] = new() { ["en"] = "▶ Start Server", ["ru"] = "▶ Запустить сервер" },
        ["server.stop_server_btn"] = new() { ["en"] = "⏹ Stop Server", ["ru"] = "⏹ Остановить сервер" },
        ["server.save_to_profile"] = new() { ["en"] = "Save to Profile", ["ru"] = "Сохранить в профиль" },

        // Dialog messages
        ["dialog.profile_exists"] = new() { ["en"] = "A profile with the name \"{0}\" already exists.", ["ru"] = "Профиль с именем «{0}» уже существует." },
        ["dialog.model_not_found"] = new() { ["en"] = "Model file not found:\n{0}", ["ru"] = "Файл модели не найден:\n{0}" },
        ["dialog.profile_created"] = new() { ["en"] = "Profile \"{0}\" created.", ["ru"] = "Профиль «{0}» создан." },
        ["dialog.profile_updated"] = new() { ["en"] = "Profile \"{0}\" updated.", ["ru"] = "Профиль «{0}» обновлён." },
        ["dialog.no_default_profile"] = new() { ["en"] = "No default profile exists. Create a profile first.", ["ru"] = "Нет профиля по умолчанию. Создайте профиль сначала." },
        ["dialog.no_model_selected"] = new() { ["en"] = "Default profile has no model selected.", ["ru"] = "В профиле по умолчанию не выбрана модель." },
        ["dialog.no_profile_to_save"] = new() { ["en"] = "No profile selected to save settings.", ["ru"] = "Не выбран профиль для сохранения настроек." },
        ["dialog.no_profile_to_export"] = new() { ["en"] = "No profile selected to export.", ["ru"] = "Не выбран профиль для экспорта." },

        // Log levels (for ComboBox)
        ["log.debug"] = new() { ["en"] = "Debug", ["ru"] = "Отладка" },
        ["log.information"] = new() { ["en"] = "Information", ["ru"] = "Информация" },
        ["log.warning"] = new() { ["en"] = "Warning", ["ru"] = "Предупреждение" },
        ["log.error"] = new() { ["en"] = "Error", ["ru"] = "Ошибка" },

        // Model metadata (for ModelsPage)
        ["model.ctx_fmt"] = new() { ["en"] = "ctx: {0}", ["ru"] = "контекст: {0}" },
        ["model.vram_fmt"] = new() { ["en"] = "~{0:F1} GB VRAM", ["ru"] = "~{0:F1} ГБ VRAM" },
        ["model.layers_fmt"] = new() { ["en"] = "{0} layers", ["ru"] = "{0} слоёв" },

        // Profile metadata (for ProfilesPage)
        ["profile.ctx_fmt"] = new() { ["en"] = "ctx: {0}", ["ru"] = "контекст: {0}" },
        ["profile.gpu_fmt"] = new() { ["en"] = "gpu: {0}", ["ru"] = "gpu: {0}" },
        ["profile.temp_fmt"] = new() { ["en"] = "temp: {0:F2}", ["ru"] = "температура: {0:F2}" },

        // Dashboard VRAM format
        ["dash.vram_gb_fmt"] = new() { ["en"] = " {0:F1} GB", ["ru"] = " {0:F1} ГБ" },

        // Settings — build type filter
        ["settings.build_type_label"] = new() { ["en"] = "Build type:", ["ru"] = "Тип сборки:" },
        ["settings.cuda12x"] = new() { ["en"] = "CUDA 12.x (Recommended)", ["ru"] = "CUDA 12.x (рекомендуется)" },
        ["settings.cuda13x"] = new() { ["en"] = "CUDA 13.x", ["ru"] = "CUDA 13.x" },
        ["settings.vulkan"] = new() { ["en"] = "Vulkan", ["ru"] = "Vulkan" },
        ["settings.cpu_only"] = new() { ["en"] = "CPU Only", ["ru"] = "Только CPU" },
        ["settings.download_install_btn"] = new() { ["en"] = "Download & Install", ["ru"] = "Скачать и установить" },
        ["settings.install_btn"] = new() { ["en"] = "Install", ["ru"] = "Установить" },
        ["settings.installing_btn"] = new() { ["en"] = "Installing...", ["ru"] = "Установка..." },

        // ToolTips
        ["tt.language"] = new() { ["en"] = "Select application language (changes apply immediately)", ["ru"] = "Выберите язык приложения (применяется сразу)" },
        ["tt.llama_cpp_dir"] = new() { ["en"] = "Directory where llama.cpp binaries are installed. Auto-set after download.", ["ru"] = "Папка с бинарниками llama.cpp. Заполняется автоматически после установки." },
        ["tt.models_dir"] = new() { ["en"] = "Directory where GGUF model files are stored.", ["ru"] = "Папка для хранения файлов моделей GGUF." },
        ["tt.auto_check_updates"] = new() { ["en"] = "Automatically check for new llama.cpp releases on startup", ["ru"] = "Автоматически проверять новые версии llama.cpp при запуске" },
        ["tt.portable_mode"] = new() { ["en"] = "Store all data in the application directory instead of AppData", ["ru"] = "Хранить все данные в папке приложения вместо AppData" },
        ["tt.theme"] = new() { ["en"] = "Application appearance theme", ["ru"] = "Тема оформления приложения" },
        ["tt.update_channel"] = new() { ["en"] = "Stable = official releases only. Prerelease includes beta builds.", ["ru"] = "Стабильная = только официальные релизы. Предварительная включает бета-сборки." },
        ["tt.host"] = new() { ["en"] = "Server listen address. 127.0.0.1 = local only, 0.0.0.0 = all interfaces.", ["ru"] = "Адрес сервера. 127.0.0.1 = только локально, 0.0.0.0 = все интерфейсы." },
        ["tt.host_default"] = new() { ["en"] = "Default: 127.0.0.1", ["ru"] = "По умолчанию: 127.0.0.1" },
        ["tt.port"] = new() { ["en"] = "Server port number (1-65535). Default: 8080", ["ru"] = "Порт сервера (1-65535). По умолчанию: 8080" },
        ["tt.port_manual"] = new() { ["en"] = "Enter port number manually", ["ru"] = "Введите номер порта вручную" },
        ["tt.gpu_layers"] = new() { ["en"] = "Number of layers to offload to GPU. 99 = all layers. 0 = CPU only.", ["ru"] = "Количество слоёв для загрузки на GPU. 99 = все слои. 0 = только CPU." },
        ["tt.gpu_layers_default"] = new() { ["en"] = "Default: 99 (all layers on GPU)", ["ru"] = "По умолчанию: 99 (все слои на GPU)" },
        ["tt.flash_attention"] = new() { ["en"] = "Enable Flash Attention for faster inference with lower memory usage", ["ru"] = "Включить Flash Attention для ускорения инференса с меньшим расходом памяти" },
        ["tt.install_build"] = new() { ["en"] = "Download and install this build", ["ru"] = "Скачать и установить эту сборку" },
    };

    public string T(string key)
    {
        if (_translations.TryGetValue(key, out var langs) && langs.TryGetValue(_language, out var value))
            return value;
        // Fallback to English
        if (langs != null && langs.TryGetValue("en", out var enValue))
            return enValue;
        return $"[{key}]";
    }

    public void ChangeLanguage(string language)
    {
        _language = language ?? "ru";
        OnLanguageChanged?.Invoke(this, _language);
    }

    public event EventHandler<string>? OnLanguageChanged;
}
