using Avalonia.Data.Converters;
using Avalonia.Media;
using Hermass.Core.Models;
using System.Globalization;

namespace Hermass.Converters;

public class EqualConverter : IValueConverter
{
    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value == null || parameter == null) return false;
        if (value.Equals(parameter)) return true;

        var valueStr = value.ToString();
        var paramStr = parameter.ToString();

        if (string.IsNullOrEmpty(valueStr) || string.IsNullOrEmpty(paramStr)) return false;

        if (valueStr == paramStr) return true;

        try
        {
            return object.Equals(
                System.Convert.ChangeType(value, typeof(double)),
                System.Convert.ChangeType(parameter, typeof(double)));
        }
        catch { return false; }
    }

    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        return parameter;
    }
}

public class BoolToStringConverter : IValueConverter
{
    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var parts = parameter?.ToString()?.Split('|');
        if (value is bool b)
        {
            if (b)
                return (parts != null && parts.Length >= 1) ? parts[0] : "True";
            return (parts != null && parts.Length >= 2) ? parts[1] : "False";
        }
        return value?.ToString() ?? string.Empty;
    }

    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        return false;
    }
}

public class GreaterThanConverter : IValueConverter
{
    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is IComparable comparable && parameter != null)
            return comparable.CompareTo(System.Convert.ChangeType(parameter, value.GetType())) > 0;
        return false;
    }

    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        return null;
    }
}

public class NotNullConverter : IValueConverter
{
    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        return value != null && !string.IsNullOrEmpty(value.ToString());
    }

    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        return null;
    }
}

public class InvertedBoolConverter : IValueConverter
    {
        public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            return value is bool b && !b;
        }

        public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            return value is bool b && !b;
        }
    }

    public class NotEqualConverter : IValueConverter
    {
        public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            if (value == null && parameter == null) return false;
            if (value == null || parameter == null) return true;
            if (value.Equals(parameter)) return false;

            var valueStr = value.ToString();
            var paramStr = parameter.ToString();
            if (string.IsNullOrEmpty(valueStr) || string.IsNullOrEmpty(paramStr))
                return string.IsNullOrEmpty(valueStr) != string.IsNullOrEmpty(paramStr);

            if (valueStr == paramStr) return false;

            try
            {
                return !object.Equals(
                    System.Convert.ChangeType(value, typeof(double)),
                    System.Convert.ChangeType(parameter, typeof(double)));
            }
            catch { return true; }
        }

        public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
        return null;
    }
}

public class BuildTypeToBrushConverter : IValueConverter
{
    static readonly Dictionary<BuildType, SolidColorBrush> _brushes = new()
    {
        { BuildType.Cuda12x, new SolidColorBrush(Color.Parse("#F59E0B")) },
        { BuildType.Cuda13x, new SolidColorBrush(Color.Parse("#A855F7")) },
        { BuildType.Vulkan, new SolidColorBrush(Color.Parse("#3B82F6")) },
        { BuildType.OpenVino, new SolidColorBrush(Color.Parse("#10B981")) },
        { BuildType.Cpu, new SolidColorBrush(Color.Parse("#64748B")) },
        { BuildType.Unknown, new SolidColorBrush(Color.Parse("#64748B")) },
    };

    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is BuildType bt && _brushes.TryGetValue(bt, out var brush))
            return brush;
        return _brushes[BuildType.Unknown];
    }

    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        return null;
    }
}

public class StringEqualBrushConverter : IValueConverter
{
    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (parameter == null) return null;
        var isActive = value?.ToString() == parameter.ToString();
        return isActive
            ? new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.Parse("27272A"))
            : null;
    }

    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        return null;
    }
}

public class SizeFormatConverter : IValueConverter
{
    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is long bytes)
        {
            return bytes switch
            {
                >= 1_073_741_824 => $"{bytes / 1_073_741_824.0:F1} GiB",
                >= 1_048_576 => $"{bytes / 1_048_576.0:F1} MiB",
                >= 1_024 => $"{bytes / 1_024.0:F1} KiB",
                _ => $"{bytes} B"
            };
        }
        return value?.ToString() ?? "0 B";
    }

    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        return null;
    }
}

public class LogLevelBrushConverter : IValueConverter
{
    static readonly Dictionary<string, Avalonia.Media.IBrush> _brushes = new()
    {
        { "Debug", new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.Parse("#64748B")) },
        { "Information", new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.Parse("#38BDF8")) },
        { "Warning", new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.Parse("#FBBF24")) },
        { "Error", new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.Parse("#F87171")) },
        { "Fatal", new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.Parse("#FF0000")) },
    };

    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var level = value?.ToString();
        return _brushes.TryGetValue(level ?? string.Empty, out var brush) ? brush : null;
    }

    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        return null;
    }
}

public class ServerStateBrushConverter : IValueConverter
{
    static readonly Dictionary<string, Avalonia.Media.IBrush> _brushes = new()
    {
        { "Stopped", new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.Parse("#64748B")) },
        { "Starting", new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.Parse("#FBBF24")) },
        { "Running", new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.Parse("#34D399")) },
        { "Stopping", new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.Parse("#FBBF24")) },
        { "Error", new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.Parse("#F87171")) },
    };

    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var state = value?.ToString();
        return _brushes.TryGetValue(state ?? string.Empty, out var brush) ? brush : null;
    }

    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        return null;
    }
}

public class StateToStringConverter : IValueConverter
{
    static readonly Dictionary<string, string> _states = new()
    {
        { "Stopped", "⏹ Stopped" },
        { "Starting", "⏳ Starting..." },
        { "Running", "▶ Running" },
        { "Stopping", "⏳ Stopping..." },
        { "Error", "⚠ Error" },
    };

    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var state = value?.ToString();
        return _states.TryGetValue(state ?? string.Empty, out var text) ? text : state;
    }

    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        return null;
    }
}