using Hermass.Core.Interfaces;
using Hermass.Core.Models;
using System.Text.Json;

namespace Hermass.Infrastructure.Profiles;

public class ProfileManager : IProfileManager
{
    public event Action<string>? ProfileChanged;

    readonly ISettings _settings;
    readonly ILogService _log;
    readonly JsonSerializerOptions _jsonOptions = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
    };

    public ProfileManager(ISettings settings, ILogService log)
    {
        _settings = settings;
        _log = log;
    }

    string GetProfilesDirectory()
    {
        var baseDir = _settings.PortableMode
            ? AppDomain.CurrentDomain.BaseDirectory
            : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Hermass");

        var profilesDir = Path.Combine(baseDir, "profiles");

        if (!Directory.Exists(profilesDir))
            Directory.CreateDirectory(profilesDir);

        return profilesDir;
    }

    string GetProfilePath(string id) => Path.Combine(GetProfilesDirectory(), $"{id}.json");

    async Task<List<ServerProfile>> IProfileManager.GetAllProfilesAsync()
    {
        var profiles = new List<ServerProfile>();
        var profilesDir = GetProfilesDirectory();

        if (!Directory.Exists(profilesDir))
            return profiles;

        var files = Directory.GetFiles(profilesDir, "*.json");

        foreach (var file in files)
        {
            try
            {
                var json = await File.ReadAllTextAsync(file);
                var profile = JsonSerializer.Deserialize<ServerProfile>(json, _jsonOptions);
                if (profile != null)
                    profiles.Add(profile);
            }
            catch (Exception ex)
            {
                _log.Error(ex, $"Failed to load profile: {file}", "ProfileManager");
            }
        }

        profiles.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
        return profiles;
    }

    async Task<ServerProfile?> IProfileManager.GetProfileAsync(string id)
    {
        var path = GetProfilePath(id);

        if (!File.Exists(path))
            return null;

        var json = await File.ReadAllTextAsync(path);
        return JsonSerializer.Deserialize<ServerProfile>(json, _jsonOptions);
    }

    async Task<string> IProfileManager.SaveProfileAsync(ServerProfile profile)
    {
        if (string.IsNullOrEmpty(profile.Id))
            profile.Id = Guid.NewGuid().ToString("N")[..8];

        profile.UpdatedAt = DateTime.Now;

        if (!profile.IsDefault)
        {
            var existingProfiles = await ((IProfileManager)this).GetAllProfilesAsync();
            if (!existingProfiles.Any(p => p.IsDefault))
                profile.IsDefault = true;
        }

        var path = GetProfilePath(profile.Id);
        var json = JsonSerializer.Serialize(profile, _jsonOptions);
        await File.WriteAllTextAsync(path, json);

        _log.Information($"Saved profile: {profile.Name} ({profile.Id})", "ProfileManager");
        ProfileChanged?.Invoke(profile.Id);
        return profile.Id;
    }

    async Task<bool> IProfileManager.DeleteProfileAsync(string id)
    {
        var path = GetProfilePath(id);

        if (!File.Exists(path))
            return false;

        File.Delete(path);
        _log.Information($"Deleted profile: {id}", "ProfileManager");
        await Task.CompletedTask;
        return true;
    }

    async Task<ServerProfile> IProfileManager.DuplicateProfileAsync(string id)
    {
        var original = await ((IProfileManager)this).GetProfileAsync(id);

        if (original == null)
            throw new ArgumentException($"Profile not found: {id}");

        var copy = new ServerProfile
        {
            Name = original.Name + " (Copy)",
            Description = original.Description,
            ModelPath = original.ModelPath,
            MmprojPath = original.MmprojPath,
            DraftModelPath = original.DraftModelPath,
            LlamaCppVersion = original.LlamaCppVersion,
            GpuLayers = original.GpuLayers,
            GpuSplitMode = original.GpuSplitMode,
            TensorSplit = original.TensorSplit.ToArray(),
            MainGpu = original.MainGpu,
            FlashAttention = original.FlashAttention,
            Mmap = original.Mmap,
            Mlock = original.Mlock,
            NoMmq = original.NoMmq,
            NoKvOffload = original.NoKvOffload,
            ContextSize = original.ContextSize,
            BatchSize = original.BatchSize,
            UbatchSize = original.UbatchSize,
            CacheTypeK = original.CacheTypeK,
            CacheTypeV = original.CacheTypeV,
            Threads = original.Threads,
            ThreadsBatch = original.ThreadsBatch,
            Temperature = original.Temperature,
            TopK = original.TopK,
            TopP = original.TopP,
            MinP = original.MinP,
            TypicalP = original.TypicalP,
            RepeatPenalty = original.RepeatPenalty,
            RepeatLastN = original.RepeatLastN,
            Mirostat = original.Mirostat,
            MirostatTau = original.MirostatTau,
            MirostatEta = original.MirostatEta,
            DryMultiplier = original.DryMultiplier,
            DryBase = original.DryBase,
            DynatempStddev = original.DynatempStddev,
            XtcProbability = original.XtcProbability,
            XtcThreshold = original.XtcThreshold,
            Host = original.Host,
            Port = original.Port,
            Timeout = original.Timeout,
            Slots = original.Slots,
            PredictCount = original.PredictCount,
            EnableMtp = original.EnableMtp,
            SpeculativeDecoding = original.SpeculativeDecoding,
            RopeFreqBase = original.RopeFreqBase,
            RopeFreqScale = original.RopeFreqScale,
            YarnOriginalContext = original.YarnOriginalContext,
            YarnExtFactor = original.YarnExtFactor,
            YarnAttnFactor = original.YarnAttnFactor,
            YarnBetaFast = original.YarnBetaFast,
            YarnBetaSlow = original.YarnBetaSlow,
            EmbeddingMode = original.EmbeddingMode,
            PoolingType = original.PoolingType,
            ProcessPriority = original.ProcessPriority,
            Numa = original.Numa,
            CpuAffinity = original.CpuAffinity,
            AdditionalArgs = original.AdditionalArgs,
            Color = original.Color,
            IsDefault = false
        };

        copy.Id = Guid.NewGuid().ToString("N")[..8];
        copy.CreatedAt = DateTime.Now;

        await ((IProfileManager)this).SaveProfileAsync(copy);
        return copy;
    }

    async Task<ServerProfile> IProfileManager.ImportProfileAsync(string json)
    {
        var profile = JsonSerializer.Deserialize<ServerProfile>(json, _jsonOptions);

        if (profile == null)
            throw new InvalidDataException("Invalid profile JSON");

        profile.Id = Guid.NewGuid().ToString("N")[..8];
        profile.CreatedAt = DateTime.Now;
        profile.UpdatedAt = DateTime.Now;

        await ((IProfileManager)this).SaveProfileAsync(profile);
        return profile;
    }

    string IProfileManager.ExportProfile(ServerProfile profile)
    {
        return JsonSerializer.Serialize(profile, _jsonOptions);
    }

    async Task IProfileManager.SetDefaultProfileAsync(string id)
    {
        var profiles = await ((IProfileManager)this).GetAllProfilesAsync();

        foreach (var p in profiles)
        {
            p.IsDefault = p.Id == id;
            await ((IProfileManager)this).SaveProfileAsync(p);
        }

        _log.Information($"Set default profile: {id}", "ProfileManager");
    }

    async Task<ServerProfile?> IProfileManager.GetDefaultProfileAsync()
    {
        var profiles = await ((IProfileManager)this).GetAllProfilesAsync();
        var @default = profiles.FirstOrDefault(p => p.IsDefault);
        if (@default != null) return @default;
        return profiles.FirstOrDefault();
    }
}
