namespace Hermass.Core.Interfaces;

public interface ISettings
{
    string LlamaCppDirectory { get; set; }
    string ModelsDirectory { get; set; }
    string AdditionalModelsDirectories { get; set; }
    string ActiveLlamaCppVersion { get; set; }
    string Theme { get; set; }
    string Language { get; set; }
    bool AutoCheckUpdates { get; set; }
    bool StartMinimized { get; set; }
    bool ShowTrayIcon { get; set; }
    bool PortableMode { get; set; }
    int MaxLogEntries { get; set; }
    string DefaultHost { get; set; }
    int DefaultPort { get; set; }
    int DefaultGpuLayers { get; set; }
    bool FlashAttention { get; set; }
    Enums.UpdateChannel UpdateChannel { get; set; }
    Task SaveAsync();
    Task LoadAsync();
    string GetSettingsPath();
}
