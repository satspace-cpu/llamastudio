using Avalonia;
using System;
using System.IO;

namespace Hermass;

class Program
{
    static readonly string _logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "crash.log");

    static void Log(string message)
    {
        File.AppendAllText(_logPath, $"{DateTime.Now:HH:mm:ss.fff} {message}{Environment.NewLine}");
    }

    [STAThread]
    public static void Main(string[] args)
    {
        AppDomain.CurrentDomain.UnhandledException += (s, e) =>
        {
            var ex = e.ExceptionObject as Exception ?? new Exception(e.ToString());
            Log($"[FATAL UNHANDLED] {ex.GetType().Name}: {ex.Message}");
            Log(ex.StackTrace ?? "no stack trace");
            if (ex.InnerException != null)
                Log($"[INNER] {ex.InnerException.GetType().Name}: {ex.InnerException.Message}");
        };
        try
        {
            var app = BuildAvaloniaApp();
            app.StartWithClassicDesktopLifetime(args);
        }
        catch (Exception ex)
        {
            Log($"[FATAL] {ex.GetType().Name}: {ex.Message}");
            Log(ex.StackTrace ?? "no stack trace");
        }
    }

    public static AppBuilder BuildAvaloniaApp()
    {
        return AppBuilder.Configure<App>()
            .UsePlatformDetect()
            .WithInterFont()
            .LogToTrace();
    }
}