using System.Reactive.Linq;
using System.Reactive.Subjects;
using Hermass.Core.Enums;
using Hermass.Core.Interfaces;
using Hermass.Core.Models;
using Serilog;
using Serilog.Core;
using Serilog.Events;

namespace Hermass.Infrastructure.Logging;

public class LogService : ILogService, IDisposable
{
    readonly Subject<LogEntry> _subject = new();
    readonly List<LogEntry> _buffer = new();
    readonly object _lock = new();
    readonly ISettings _settings;
    readonly Logger _logger;

    public IObservable<LogEntry> LogStream => _subject.AsObservable();

    public LogService(ISettings settings)
    {
        _settings = settings;

        _logger = new LoggerConfiguration()
            .MinimumLevel.Debug()
            .WriteTo.Console(
                outputTemplate: "[{Timestamp:HH:mm:ss.fff}] [{Level:u3}] [{SourceContext}] {Message:lj}{NewLine}{Exception}")
            .WriteTo.File(
                Path.Combine(GetLogDirectory(), "hermass_.log"),
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: 7,
                rollOnFileSizeLimit: true,
                fileSizeLimitBytes: 10_485_760,
                outputTemplate: "[{Timestamp:HH:mm:ss.fff}] [{Level:u3}] [{SourceContext}] {Message:lj}{NewLine}{Exception}")
            .WriteTo.Sink(new InternalLogSink(this))
            .CreateLogger();

        Serilog.Log.Logger = _logger;
    }

    string GetLogDirectory()
    {
        if (_settings.PortableMode)
        {
            return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs");
        }

        return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Hermass", "logs");
    }

    internal void Emit(LogEvent logEvent)
    {
        var entry = new LogEntry
        {
            Timestamp = logEvent.Timestamp.UtcDateTime,
            Level = MapLevel(logEvent.Level),
            Source = logEvent.Properties.ContainsKey("SourceContext")
                ? logEvent.Properties["SourceContext"].ToString()?.Split('.').Last() ?? "App"
                : "App",
            Message = logEvent.RenderMessage(),
            Exception = logEvent.Exception?.ToString()
        };

        lock (_lock)
        {
            _buffer.Add(entry);
            var maxEntries = _settings.MaxLogEntries;
            while (_buffer.Count > maxEntries)
                _buffer.RemoveAt(0);
        }

        _subject.OnNext(entry);
    }

    static LogLevel MapLevel(LogEventLevel level)
        => level switch
        {
            LogEventLevel.Debug => LogLevel.Debug,
            LogEventLevel.Information => LogLevel.Information,
            LogEventLevel.Warning => LogLevel.Warning,
            LogEventLevel.Error => LogLevel.Error,
            LogEventLevel.Fatal => LogLevel.Fatal,
            _ => LogLevel.Information
        };

    public void Debug(string message, string source = "App")
        => _logger.ForContext("SourceContext", source).Debug(message);

    public void Information(string message, string source = "App")
        => _logger.ForContext("SourceContext", source).Information(message);

    public void Warning(string message, string source = "App")
        => _logger.ForContext("SourceContext", source).Warning(message);

    public void Error(string message, string source = "App")
        => _logger.ForContext("SourceContext", source).Error(message);

    public void Error(Exception exception, string message, string source = "App")
        => _logger.ForContext("SourceContext", source).Error(exception, message);

    public List<LogEntry> GetRecentLogs(int count = 100)
    {
        lock (_lock)
        {
            return _buffer.TakeLast(count).ToList();
        }
    }

    public async Task ExportLogsAsync(string path)
    {
        var lines = new List<string>();
        lock (_lock)
        {
            lines = _buffer.Select(e =>
                $"[{e.Timestamp:yyyy-MM-dd HH:mm:ss.fff}] [{e.Level}] [{e.Source}] {e.Message}").ToList();
        }
        await File.WriteAllLinesAsync(path, lines);
    }

    public Task ClearLogsAsync()
    {
        lock (_lock)
        {
            _buffer.Clear();
        }
        return Task.CompletedTask;
    }

    public void Dispose()
    {
        _subject.OnCompleted();
        _subject.Dispose();
        _logger.Dispose();
    }

    // Internal sink to route Serilog events to our Subject
    class InternalLogSink : ILogEventSink
    {
        readonly LogService _service;
        public InternalLogSink(LogService service) => _service = service;
        public void Emit(LogEvent logEvent) => _service.Emit(logEvent);
    }
}
