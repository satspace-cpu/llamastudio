using Hermass.Core.Enums;
using Hermass.Core.Interfaces;
using Hermass.Core.Models;
using System.Diagnostics;
using System.Text.Json;

namespace Hermass.Infrastructure.Llama;

public class ServerManager : IServerManager, IDisposable
{
    readonly ILogService _log;
    readonly ISettings _settings;
    Process? _process;
    CancellationTokenSource? _cts;
    readonly object _lock = new();
    DateTime? _startedAt;
    ServerStatus _status = new() { State = ServerState.Stopped };

    public event EventHandler<ServerStatus>? StatusChanged;
    public event EventHandler<LogEntry>? LogReceived;

    public ServerManager(ILogService log, ISettings settings)
    {
        _log = log;
        _settings = settings;
    }

    async Task<ServerStatus> IServerManager.GetStatusAsync()
    {
        ServerStatus s;
        lock (_lock)
        {
            s = new ServerStatus
            {
                State = _status.State,
                Port = _status.Port,
                Host = _status.Host,
                ModelName = _status.ModelName,
                ContextSize = _status.ContextSize,
                Threads = _status.Threads,
                GpuLayers = _status.GpuLayers,
                VramUsedGb = _status.VramUsedGb,
                RamUsedGb = _status.RamUsedGb,
                TokensPerSecond = _status.TokensPerSecond,
                QueueSize = _status.QueueSize,
                ActiveSlots = _status.ActiveSlots,
                TotalTokensProcessed = _status.TotalTokensProcessed,
                Uptime = _startedAt.HasValue ? DateTime.Now - _startedAt.Value : TimeSpan.Zero,
                StartedAt = _startedAt,
                ErrorMessage = _status.ErrorMessage,
                ProcessId = _process?.Id
            };
        }
        await Task.CompletedTask;
        return s;
    }

    async Task IServerManager.StartAsync(ServerProfile profile, CancellationToken cancellationToken)
    {
        if (_process != null && !_process.HasExited)
        {
            _log.Warning("Server already running", "ServerManager");
            return;
        }

        lock (_lock)
        {
            _status = new ServerStatus
            {
                State = ServerState.Starting,
                Port = profile.Port,
                Host = profile.Host,
                ModelName = Path.GetFileName(profile.ModelPath ?? string.Empty)
            };
        }

        RaiseStatusChanged();
        _log.Information($"Starting server with profile: {profile.Name}", "ServerManager");

        try
        {
            var exePath = Path.Combine(_settings.LlamaCppDirectory, "llama-server.exe");
            if (!File.Exists(exePath))
            {
                var errorMsg = $"llama-server.exe not found at: {exePath}";
                _log.Error(errorMsg, "ServerManager");
                lock (_lock)
                {
                    _status.State = ServerState.Error;
                    _status.ErrorMessage = errorMsg;
                }
                RaiseStatusChanged();
                return;
            }

            if (string.IsNullOrWhiteSpace(profile.ModelPath))
            {
                var errorMsg = "Model path is not specified in profile";
                _log.Error(errorMsg, "ServerManager");
                lock (_lock)
                {
                    _status.State = ServerState.Error;
                    _status.ErrorMessage = errorMsg;
                }
                RaiseStatusChanged();
                return;
            }

            if (!File.Exists(profile.ModelPath))
            {
                var errorMsg = $"Model file not found: {profile.ModelPath}";
                _log.Error(errorMsg, "ServerManager");
                lock (_lock)
                {
                    _status.State = ServerState.Error;
                    _status.ErrorMessage = errorMsg;
                }
                RaiseStatusChanged();
                return;
            }

            var args = BuildServerArgs(profile);
            _log.Information($"Command: {exePath} {args}", "ServerManager");

            _cts = new CancellationTokenSource();

            var startInfo = new ProcessStartInfo
            {
                FileName = exePath,
                Arguments = args,
                WorkingDirectory = _settings.LlamaCppDirectory,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden,
                Environment =
                {
                    ["LLAMA_NO_COLOR"] = "1"
                }
            };

            _process = new Process { StartInfo = startInfo };
            _process.OutputDataReceived += (s, e) =>
            {
                if (!string.IsNullOrEmpty(e.Data))
                    OnLogReceived(new LogEntry { Level = LogLevel.Information, Message = e.Data, Source = "Server" });
            };
            _process.ErrorDataReceived += (s, e) =>
            {
                if (!string.IsNullOrEmpty(e.Data))
                    OnLogReceived(new LogEntry { Level = LogLevel.Warning, Message = e.Data, Source = "Server", IsStderr = true });
            };
            _process.Exited += (s, e) =>
            {
                _log.Information("Server process exited", "ServerManager");
                lock (_lock)
                {
                    if (_status.State != ServerState.Stopped)
                    {
                        _status.State = ServerState.Stopped;
                        _startedAt = null;
                    }
                }
                RaiseStatusChanged();
            };

            _process.Start();
            _process.BeginOutputReadLine();
            _process.BeginErrorReadLine();

            if (!string.IsNullOrEmpty(profile.ProcessPriority) && profile.ProcessPriority != "Normal")
            {
                try
                {
                    _process.PriorityClass = (ProcessPriorityClass)Enum.Parse(typeof(ProcessPriorityClass), profile.ProcessPriority);
                }
                catch
                {
                    _log.Warning($"Invalid process priority: {profile.ProcessPriority}", "ServerManager");
                }
            }

            lock (_lock)
            {
                _status.State = ServerState.Running;
                _status.ProcessId = _process.Id;
                _startedAt = DateTime.Now;
            }

            RaiseStatusChanged();
            _log.Information($"Server started (PID: {_process.Id})", "ServerManager");

            var healthCts = new CancellationTokenSource();
            _ = Task.Run(async () =>
            {
                var timeout = TimeSpan.FromSeconds(60);
                using var timer = new System.Timers.Timer(2000) { AutoReset = true };
                timer.Elapsed += async (s, e) =>
                {
                    try
                    {
                        var health = await ((IServerManager)this).HealthCheckAsync(profile.Host, profile.Port);
                        if (health.State == ServerState.Running)
                        {
                            lock (_lock)
                            {
                                _status.TokensPerSecond = health.TokensPerSecond;
                                _status.ActiveSlots = health.ActiveSlots;
                                _status.ModelName = health.ModelName;
                                _status.ContextSize = health.ContextSize;
                            }
                            RaiseStatusChanged();
                        }
                    }
                    catch { }
                };
                timer.Start();

                using var timeoutCts = new CancellationTokenSource(timeout);
                try
                {
                    while (!healthCts.Token.IsCancellationRequested && !_cts!.Token.IsCancellationRequested)
                    {
                        await Task.Delay(2000, healthCts.Token);
                    }
                }
                catch (OperationCanceledException) { }
                finally
                {
                    timer.Stop();
                    timer.Dispose();
                }
            }, healthCts.Token);

            await Task.CompletedTask;
        }
        catch (Exception ex)
        {
            _log.Error(ex, "Failed to start server", "ServerManager");
            lock (_lock)
            {
                _status.State = ServerState.Error;
                _status.ErrorMessage = ex.Message;
            }
            RaiseStatusChanged();
        }
    }

    async Task IServerManager.StopAsync(CancellationToken cancellationToken)
    {
        if (_process == null || _process.HasExited)
        {
            return;
        }

        lock (_lock)
        {
            _status.State = ServerState.Stopping;
        }
        RaiseStatusChanged();
        _log.Information("Stopping server...", "ServerManager");

        _cts?.Cancel();

        try
        {
            if (!_process.HasExited)
            {
                _process.Kill(true);
            }
        }
        catch (Exception ex)
        {
            _log.Error(ex, "Error stopping server", "ServerManager");
        }

        if (_process.WaitForExit(10000))
        {
            _log.Information("Server stopped gracefully", "ServerManager");
        }
        else
        {
            _log.Warning("Server did not stop in time", "ServerManager");
        }

        lock (_lock)
        {
            _status.State = ServerState.Stopped;
            _startedAt = null;
        }

        RaiseStatusChanged();
        await Task.CompletedTask;
    }

    async Task<ServerStatus> IServerManager.HealthCheckAsync(string host, int port)
    {
        try
        {
            using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(5) };
            var response = await client.GetAsync($"http://{host}:{port}/health");
            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;

                return new ServerStatus
                {
                    State = ServerState.Running,
                    Port = port,
                    Host = host,
                    ModelName = root.TryGetProperty("model_name", out var modelName) ? modelName.GetString() : null,
                    ContextSize = root.TryGetProperty("ctx_size", out var ctxSize) ? ctxSize.GetInt32() : 0,
                    Threads = root.TryGetProperty("n_threads", out var threads) ? threads.GetInt32() : 0,
                    GpuLayers = root.TryGetProperty("n_gpu_layers", out var gpuLayers) ? gpuLayers.GetInt32() : 0,
                    TokensPerSecond = root.TryGetProperty("tps", out var tps) ? tps.GetDouble() : 0,
                    ActiveSlots = root.TryGetProperty("load", out var load) ? load.TryGetProperty("current", out var current) ? current.GetInt32() : 0 : 0
                };
            }
        }
        catch (Exception ex)
        {
            _log.Debug($"Health check failed: {ex.Message}", "ServerManager");
        }

        return new ServerStatus { State = ServerState.Stopped };
    }

    string BuildServerArgs(ServerProfile profile)
    {
        var args = new List<string>();

        if (!string.IsNullOrEmpty(profile.ModelPath))
        {
            args.Add("-m");
            args.Add(profile.ModelPath);
        }

        if (!string.IsNullOrEmpty(profile.MmprojPath))
        {
            args.Add("--mmproj");
            args.Add(profile.MmprojPath);
        }

        if (!string.IsNullOrEmpty(profile.DraftModelPath) && profile.SpeculativeDecoding)
        {
            args.Add("-m");
            args.Add(profile.DraftModelPath);

            if (profile.SpecDraftGpuLayers >= 0)
            {
                args.Add("--draft-gpu-layers");
                args.Add(profile.SpecDraftGpuLayers.ToString());
            }

            if (profile.SpecDraftNMax > 0)
            {
                args.Add("--draft-maxlen");
                args.Add(profile.SpecDraftNMax.ToString());
            }

            if (profile.SpecDraftNMin > 0)
            {
                args.Add("--draft-min-len");
                args.Add(profile.SpecDraftNMin.ToString());
            }

            if (profile.SpecDraftPSplit > 0 && profile.SpecDraftPSplit <= 1)
            {
                args.Add("--draft-split");
                args.Add(profile.SpecDraftPSplit.ToString("0.00"));
            }

            if (profile.SpecDraftPMin > 0 && profile.SpecDraftPMin <= 1)
            {
                args.Add("--draft-p-min");
                args.Add(profile.SpecDraftPMin.ToString("0.00"));
            }
        }

        args.Add("-ngl");
        args.Add(profile.GpuLayers.ToString());

        if (profile.GpuSplitMode != GpuSplitMode.None && profile.TensorSplit.Length > 0)
        {
            args.Add("--tensor-split");
            args.Add(string.Join(",", profile.TensorSplit));
        }

        if (profile.MainGpu > 0)
        {
            args.Add("--main-gpu");
            args.Add(profile.MainGpu.ToString());
        }

        args.Add("-c");
        args.Add(profile.ContextSize.ToString());

        args.Add("-b");
        args.Add(profile.BatchSize.ToString());

        args.Add("-ub");
        args.Add(profile.UbatchSize.ToString());

        if (profile.Threads > 0)
        {
            args.Add("-t");
            args.Add(profile.Threads.ToString());
        }

        if (profile.ThreadsBatch > 0)
        {
            args.Add("-tb");
            args.Add(profile.ThreadsBatch.ToString());
        }

        if (profile.Slots > 0)
        {
            args.Add("-s");
            args.Add(profile.Slots.ToString());
        }

        args.Add("--host");
        args.Add(profile.Host);

        args.Add("--port");
        args.Add(profile.Port.ToString());

        args.Add("--timeout");
        args.Add(profile.Timeout.ToString());

        if (profile.FlashAttention)
            args.Add("-fa");

        if (profile.Mmap)
            args.Add("--mmap");
        else
            args.Add("--no-mmap");

        if (profile.Mlock)
            args.Add("--mlock");

        if (profile.NoKvOffload)
            args.Add("--no-kv-offload");

        if (profile.NoMmq)
            args.Add("--no-mmq");

        if (profile.Numa)
            args.Add("--numa");

        args.Add("-ctk");
        args.Add(profile.CacheTypeK.ToString().ToLower());

        args.Add("-ctv");
        args.Add(profile.CacheTypeV.ToString().ToLower());

        if (profile.EnableMtp)
            args.Add("--mtp");

        args.Add("--temp");
        args.Add(profile.Temperature.ToString("0.00"));

        args.Add("--top-k");
        args.Add(profile.TopK.ToString());

        args.Add("--top-p");
        args.Add(profile.TopP.ToString("0.00"));

        args.Add("--min-p");
        args.Add(profile.MinP.ToString("0.00"));

        args.Add("--typical-p");
        args.Add(profile.TypicalP.ToString("0.00"));

        args.Add("--repeat-penalty");
        args.Add(profile.RepeatPenalty.ToString("0.00"));

        args.Add("--repeat-last-n");
        args.Add(profile.RepeatLastN.ToString());

        if (profile.Mirostat)
        {
            args.Add("--mirostat");
            args.Add("--mirostat-tau");
            args.Add(profile.MirostatTau.ToString("0.0"));
            args.Add("--mirostat-eta");
            args.Add(profile.MirostatEta.ToString("0.00"));
        }

        if (profile.DryMultiplier > 0)
        {
            args.Add("--dry-multiplier");
            args.Add(profile.DryMultiplier.ToString("0.00"));
            args.Add("--dry-base");
            args.Add(profile.DryBase.ToString("0.00"));
        }

        if (profile.DynatempStddev > 0)
        {
            args.Add("--dynatemp-stddev");
            args.Add(profile.DynatempStddev.ToString("0.00"));
        }

        if (profile.XtcProbability > 0)
        {
            args.Add("--xtc-probability");
            args.Add(profile.XtcProbability.ToString("0.00"));
            args.Add("--xtc-threshold");
            args.Add(profile.XtcThreshold.ToString("0.00"));
        }

        if (profile.PredictCount > 0)
        {
            args.Add("--predict");
            args.Add(profile.PredictCount.ToString());
        }

        if (profile.RopeFreqBase.HasValue)
        {
            args.Add("--rope-frequency-base");
            args.Add(profile.RopeFreqBase.Value.ToString());
        }

        if (profile.RopeFreqScale.HasValue)
        {
            args.Add("--rope-frequency-scale");
            args.Add(profile.RopeFreqScale.Value.ToString());
        }

        if (profile.YarnOriginalContext.HasValue)
        {
            args.Add("--yarn-orig-ctx");
            args.Add(profile.YarnOriginalContext.Value.ToString());
        }

        if (profile.YarnExtFactor.HasValue)
        {
            args.Add("--yarn-ext-factor");
            args.Add(profile.YarnExtFactor.Value.ToString());
        }

        if (profile.YarnAttnFactor.HasValue)
        {
            args.Add("--yarn-attn-factor");
            args.Add(profile.YarnAttnFactor.Value.ToString());
        }

        if (profile.YarnBetaFast.HasValue)
        {
            args.Add("--yarn-beta-fast");
            args.Add(profile.YarnBetaFast.Value.ToString());
        }

        if (profile.YarnBetaSlow.HasValue)
        {
            args.Add("--yarn-beta-slow");
            args.Add(profile.YarnBetaSlow.Value.ToString());
        }

        if (profile.EmbeddingMode)
        {
            args.Add("--embedding");

            if (!string.IsNullOrEmpty(profile.PoolingType))
            {
                args.Add("--pooling");
                args.Add(profile.PoolingType);
            }
        }

        // API key
        if (!string.IsNullOrEmpty(profile.ApiKey))
        {
            args.Add("--api-key");
            args.Add(profile.ApiKey);
        }

        // Alias
        if (!string.IsNullOrEmpty(profile.Alias))
        {
            args.Add("--alias");
            args.Add(profile.Alias);
        }

        // Reasoning
        if (profile.Reasoning)
        {
            args.Add("--reasoning");
            if (profile.ReasoningBudget > 0)
            {
                args.Add("--reasoning-budget");
                args.Add(profile.ReasoningBudget.ToString());
            }
        }

        // Seed
        if (profile.Seed >= 0)
        {
            args.Add("--seed");
            args.Add(profile.Seed.ToString());
        }

        // Presence & frequency penalty
        if (profile.PresencePenalty != 0f)
        {
            args.Add("--presence-penalty");
            args.Add(profile.PresencePenalty.ToString("0.00"));
        }

        if (profile.FrequencyPenalty != 0f)
        {
            args.Add("--frequency-penalty");
            args.Add(profile.FrequencyPenalty.ToString("0.00"));
        }

        // Max tokens
        if (profile.MaxTokens > 0)
        {
            args.Add("--max-tokens");
            args.Add(profile.MaxTokens.ToString());
        }

        // Cache prompt
        if (!profile.CachePrompt)
        {
            args.Add("--no-cache-prompt");
        }

        // Continuous batching
        if (profile.ContBatching)
        {
            args.Add("--cont-batching");
        }

        // Verbose logging
        if (profile.VerboseLogging)
        {
            args.Add("--verbose");
        }

        // Web UI
        if (profile.EnableWebUI)
        {
            args.Add("--enable-webui");
        }

        // Slots
        if (profile.EnableSlots)
        {
            args.Add("--enable-slots");
        }

        // Metrics
        if (profile.EnableMetrics)
        {
            args.Add("--enable-metrics");
        }

        if (!string.IsNullOrEmpty(profile.AdditionalArgs))
        {
            args.Add(profile.AdditionalArgs);
        }

        return string.Join(" ", args);
    }

    public void Dispose()
    {
        _cts?.Cancel();
        _cts?.Dispose();

        if (_process != null && !_process.HasExited)
        {
            try
            {
                _process.Kill(true);
            }
            catch { }
            _process.Dispose();
        }
    }

    void OnLogReceived(LogEntry entry)
    {
        LogReceived?.Invoke(this, entry);
        switch (entry.Level)
        {
            case LogLevel.Debug:
                _log.Debug(entry.Message, entry.Source);
                break;
            case LogLevel.Information:
                _log.Information(entry.Message, entry.Source);
                break;
            case LogLevel.Warning:
                _log.Warning(entry.Message, entry.Source);
                break;
            case LogLevel.Error:
            case LogLevel.Fatal:
                _log.Error(entry.Message, entry.Source);
                break;
        }
    }

    void RaiseStatusChanged()
    {
        ServerStatus s;
        lock (_lock)
        {
            s = new ServerStatus
            {
                State = _status.State,
                Port = _status.Port,
                Host = _status.Host,
                ModelName = _status.ModelName,
                ContextSize = _status.ContextSize,
                Threads = _status.Threads,
                GpuLayers = _status.GpuLayers,
                VramUsedGb = _status.VramUsedGb,
                RamUsedGb = _status.RamUsedGb,
                TokensPerSecond = _status.TokensPerSecond,
                QueueSize = _status.QueueSize,
                ActiveSlots = _status.ActiveSlots,
                TotalTokensProcessed = _status.TotalTokensProcessed,
                Uptime = _status.Uptime,
                StartedAt = _status.StartedAt,
                ErrorMessage = _status.ErrorMessage,
                ProcessId = _status.ProcessId
            };
        }
        StatusChanged?.Invoke(this, s);
    }
}
