  using Avalonia.Controls;
using Avalonia.Controls.Templates;
using Hermass.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace Hermass;

public class ViewLocator : IDataTemplate
{
    public Control? Build(object? param)
    {
        if (param is null)
            return null;

        var name = param.GetType().FullName?.Replace("ViewModel", "View");

        if (name != null)
        {
            var type = Type.GetType(name);
            if (type != null)
            {
                return (Control)Activator.CreateInstance(type)!;
            }
        }

        return new TextBlock { Text = "Not Found: " + param.GetType().FullName };
    }

    public bool Match(object? data)
    {
        if (data == null) return false;
        // Only match ViewModel types, not Controls or primitives
        return data.GetType().FullName?.EndsWith("ViewModel") ?? false;
    }
}
