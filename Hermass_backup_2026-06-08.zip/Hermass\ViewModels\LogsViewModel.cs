using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Hermass.Core.Interfaces;
using Hermass.Core.Models;
using System.Collections.ObjectModel;

namespace Hermass.ViewModels;

public partial class LogsViewModel : ObservableObject
{
    readonly ILogService _logService;
    readonly ILocalizationService _loc;
    readonly object _lock = new();
    readonly List<LogEntry> _allEntries = new();

    [ObservableProperty] ObservableCollection<LogEntry> _entries = new();
    [ObservableProperty] string _filterText = "";
    [ObservableProperty] string _minLevel = "Debug";
    [ObservableProperty] int _totalCount;

    // Translated strings
    public string Title => _loc.T("logs.title");
    public string SearchPlaceholder => _loc.T("logs.search_placeholder");
    public string MinLevelLabel => _loc.T("logs.min_level_label");
    public string ExportBtn => _loc.T("logs.export_btn");
    public string ClearBtn => _loc.T("logs.clear_btn");
    public string LogDebug => _loc.T("log.debug");
    public string LogInformation => _loc.T("log.information");
    public string LogWarning => _loc.T("log.warning");
    public string LogError => _loc.T("log.error");

    static readonly Dictionary<string, int> LevelPriority = new()
    {
        { "Debug", 0 }, { "Information", 1 }, { "Warning", 2 }, { "Error", 3 }, { "Fatal", 4 }
    };

    public LogsViewModel(ILogService logService, ILocalizationService loc)
    {
        _logService = logService;
        _loc = loc;
        _loc.OnLanguageChanged += OnLanguageChanged;

        _logService.LogStream.Subscribe(entry =>
        {
            lock (_lock)
            {
                _allEntries.Add(entry);
                TotalCount = _allEntries.Count;
            }
            ApplyFilters();
        });
    }

    void OnLanguageChanged(object? sender, string language)
    {
        foreach (var prop in new[]
        {
            nameof(Title), nameof(SearchPlaceholder), nameof(MinLevelLabel),
            nameof(ExportBtn), nameof(ClearBtn), nameof(LogDebug), nameof(LogInformation),
            nameof(LogWarning), nameof(LogError)
        })
            OnPropertyChanged(prop);
    }

    partial void OnFilterTextChanged(string value) => ApplyFilters();
    partial void OnMinLevelChanged(string value) => ApplyFilters();

    void ApplyFilters()
    {
        var minPri = LevelPriority.TryGetValue(MinLevel, out var p) ? p : 0;

        var filtered = _allEntries
            .Where(e => LevelPriority.TryGetValue(e.Level.ToString(), out var ep) && ep >= minPri)
            .ToList();

        if (!string.IsNullOrWhiteSpace(FilterText))
        {
            var lower = FilterText.ToLower();
            filtered = filtered.Where(e =>
                e.Message.ToLower().Contains(lower) ||
                e.Source.ToLower().Contains(lower) ||
                e.Level.ToString().ToLower().Contains(lower))
                .ToList();
        }

        lock (_lock)
        {
            Entries.Clear();
            foreach (var entry in filtered)
                Entries.Add(entry);
        }
    }

    [RelayCommand]
    async Task ExportLogs()
    {
        var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, $"hermass_logs_{DateTime.Now:yyyyMMdd_HHmmss}.txt");
        await _logService.ExportLogsAsync(path);
    }

    [RelayCommand]
    async Task ClearLogs()
    {
        lock (_lock)
        {
            _allEntries.Clear();
            Entries.Clear();
        }
        await _logService.ClearLogsAsync();
    }
}