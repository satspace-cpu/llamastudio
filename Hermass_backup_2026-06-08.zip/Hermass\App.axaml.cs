using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Hermass.Core.Interfaces;
using Hermass.Core.Services;
using Hermass.Infrastructure.Logging;
using Hermass.Infrastructure.Llama;
using Hermass.Infrastructure.Models;
using Hermass.Infrastructure.Profiles;
using Hermass.Infrastructure.Updater;
using Hermass.Services;
using Hermass.ViewModels;
using Hermass.Views;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Hermass;

public partial class App : Application
{
    public static IServiceProvider? Services { get; private set; }

    public override void Initialize()
    {
        base.Initialize();
    }

    public override async void OnFrameworkInitializationCompleted()
    {
        try
        {
            var host = CreateHost();
            Services = host.Services;

            // Load settings before creating any views/viewmodels
            var settings = Services.GetRequiredService<ISettings>();
            await settings.LoadAsync();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"Failed to create host: {ex}");
            base.OnFrameworkInitializationCompleted();
            return;
        }

        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            try
            {
                var mainWindow = Services!.GetRequiredService<MainWindow>();
                desktop.MainWindow = mainWindow;
                mainWindow.Show();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Failed to show window: {ex.GetType().Name}: {ex.Message}");
                if (ex.InnerException != null)
                    System.Diagnostics.Debug.WriteLine($"  Inner: {ex.InnerException.GetType().Name}: {ex.InnerException.Message}");
            }

            desktop.Exit += (s, e) =>
            {
                var serverManager = Services.GetService<IServerManager>();
                serverManager?.StopAsync().Wait();

                var settingsVm = Services.GetService<SettingsViewModel>();
                settingsVm?.Dispose();

                // Save settings on exit
                var settings = Services.GetRequiredService<ISettings>();
                settings.SaveAsync().Wait();
            };
        }

        base.OnFrameworkInitializationCompleted();
    }

    static IHost CreateHost()
    {
        return Host.CreateDefaultBuilder()
            .ConfigureServices((context, services) =>
            {
                services.AddSingleton(new HttpClient());

                services.AddSingleton<ILocalizationService, LocalizationService>();
                services.AddSingleton<ISettings, AppSettings>();
                services.AddSingleton<ILogService, LogService>();
                services.AddSingleton<ILlamaUpdater, LlamaUpdater>();
                services.AddSingleton<IServerManager, ServerManager>();
                services.AddSingleton<IModelScanner, ModelScanner>();
                services.AddSingleton<IProfileManager, ProfileManager>();

                services.AddSingleton<INavigationService>(sp =>
                    new NavigationService(() => sp.GetRequiredService<MainViewModel>()));

                services.AddSingleton<MainViewModel>();
                services.AddSingleton<DashboardViewModel>();
                services.AddSingleton<ModelsViewModel>();
                services.AddSingleton<ServerViewModel>();
                services.AddSingleton<ProfilesViewModel>();
                services.AddSingleton<LogsViewModel>();
                services.AddSingleton<SettingsViewModel>();

                services.AddSingleton<MainWindow>();
                services.AddSingleton<IDialogService>(sp =>
                    new DialogService(() => sp.GetRequiredService<MainWindow>()));
            })
            .Build();
    }
}