namespace Hermass.Core.Interfaces;

public interface INavigationService
{
    void Navigate(string page);
}