using Hermass.Core.Enums;
using Hermass.Core.Interfaces;
using System.Text.Json;

namespace Hermass.Infrastructure.Models;

public class AppSettings : ISettings
{
    const string DefaultJson = """
    {
      "LlamaCppDirectory": "",
      "ModelsDirectory": "",
      "AdditionalModelsDirectories": "",
      "ActiveLlamaCppVersion": "",
      "Theme": "Dark",
      "Language": "en",
      "AutoCheckUpdates": true,
      "StartMinimized": false,
      "ShowTrayIcon": true,
      "PortableMode": true,
      "MaxLogEntries": 5000,
      "DefaultHost": "127.0.0.1",
      "DefaultPort": 8080,
      "DefaultGpuLayers": 99,
      "FlashAttention": true,
      "UpdateChannel": "Stable"
    }
    """;

    public string LlamaCppDirectory { get; set; } = string.Empty;
    public string ModelsDirectory { get; set; } = string.Empty;
    public string AdditionalModelsDirectories { get; set; } = string.Empty;
    public string ActiveLlamaCppVersion { get; set; } = string.Empty;
    public string Theme { get; set; } = "Dark";
    public string Language { get; set; } = "en";
    public bool AutoCheckUpdates { get; set; } = true;
    public bool StartMinimized { get; set; }
    public bool ShowTrayIcon { get; set; } = true;
    public bool PortableMode { get; set; } = true;
    public int MaxLogEntries { get; set; } = 5000;
    public string DefaultHost { get; set; } = "127.0.0.1";
    public int DefaultPort { get; set; } = 8080;
    public int DefaultGpuLayers { get; set; } = 99;
    public bool FlashAttention { get; set; } = true;
    public UpdateChannel UpdateChannel { get; set; } = UpdateChannel.Stable;

    public string GetSettingsPath() => _settingsPath;
    string _settingsPath;

    public AppSettings()
    {
        _settingsPath = GetDefaultSettingsPath();
    }

    static string GetDefaultSettingsPath()
    {
        var isPortable = File.Exists(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "portable.txt"));

        if (isPortable)
        {
            return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "settings.json");
        }

        var appData = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "HermassLlamaServer");

        if (!Directory.Exists(appData))
            Directory.CreateDirectory(appData);

        return Path.Combine(appData, "settings.json");
    }

    public async Task LoadAsync()
    {
        try
        {
            if (File.Exists(_settingsPath))
            {
                var json = await File.ReadAllTextAsync(_settingsPath);
                var opts = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true,
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                };
                var data = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(json, opts);
                if (data == null) return;

                if (data.TryGetValue("llamaCppDirectory", out var d1)) LlamaCppDirectory = d1.GetString() ?? string.Empty;
                if (data.TryGetValue("modelsDirectory", out var d2)) ModelsDirectory = d2.GetString() ?? string.Empty;
                if (data.TryGetValue("additionalModelsDirectories", out var d3)) AdditionalModelsDirectories = d3.GetString() ?? string.Empty;
                if (data.TryGetValue("activeLlamaCppVersion", out var d4)) ActiveLlamaCppVersion = d4.GetString() ?? string.Empty;
                if (data.TryGetValue("theme", out var d5)) Theme = d5.GetString() ?? "Dark";
                if (data.TryGetValue("language", out var d6)) Language = d6.GetString() ?? "en";
                if (data.TryGetValue("autoCheckUpdates", out var d7)) AutoCheckUpdates = d7.GetBoolean();
                if (data.TryGetValue("startMinimized", out var d8)) StartMinimized = d8.GetBoolean();
                if (data.TryGetValue("showTrayIcon", out var d9)) ShowTrayIcon = d9.GetBoolean();
                if (data.TryGetValue("portableMode", out var d10)) PortableMode = d10.GetBoolean();
                if (data.TryGetValue("maxLogEntries", out var d11)) MaxLogEntries = d11.GetInt32();
                if (data.TryGetValue("defaultHost", out var d12)) DefaultHost = d12.GetString() ?? "127.0.0.1";
                if (data.TryGetValue("defaultPort", out var d13)) DefaultPort = d13.GetInt32();
                if (data.TryGetValue("defaultGpuLayers", out var d14)) DefaultGpuLayers = d14.GetInt32();
                if (data.TryGetValue("flashAttention", out var d15)) FlashAttention = d15.GetBoolean();
                if (data.TryGetValue("updateChannel", out var d16))
                    UpdateChannel = Enum.TryParse<UpdateChannel>(d16.GetString(), true, out var ch) ? ch : UpdateChannel.Stable;
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"Error loading settings: {ex.Message}");
        }
    }

    public async Task SaveAsync()
    {
        try
        {
            var dir = Path.GetDirectoryName(_settingsPath);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            var opts = new JsonSerializerOptions
            {
                WriteIndented = true,
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            };
            var json = JsonSerializer.Serialize(this, opts);
            await File.WriteAllTextAsync(_settingsPath, json);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"Error saving settings: {ex.Message}");
        }
    }
}
