using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Hermass.Core.Enums;
using Hermass.Core.Models;
using Hermass.Core.Interfaces;

namespace Hermass.ViewModels;

public partial class DashboardViewModel : ObservableObject
{
    readonly IServerManager _serverManager;
    readonly IModelScanner _modelScanner;
    readonly IProfileManager _profileManager;
    readonly ISettings _settings;
    readonly INavigationService _navigation;
    readonly ILocalizationService _loc;

    [ObservableProperty] ServerStatus _serverStatus = new();
    [ObservableProperty] int _totalModels;
    [ObservableProperty] int _totalProfiles;
    [ObservableProperty] string _activeVersion = "Not installed";
    [ObservableProperty] double _estimatedVramGb;
    [ObservableProperty] double _vramPercentage;
    [ObservableProperty] string _selectedModel = "No model selected";

    // Translated strings
    public string Title => _loc.T("dash.title");
    public string ServerLabel => _loc.T("dash.server_label");
    public string ModelsCard => _loc.T("main.models");
    public string Indexed => _loc.T("dash.indexed");
    public string ProfilesCard => _loc.T("main.profiles");
    public string Saved => _loc.T("dash.saved");
    public string LlamaCppCard => _loc.T("dash.llama_cpp");
    public string ActiveBadge => _loc.T("dash.active");
    public string VramUsage => _loc.T("dash.vram_usage");
    public string GpuMemory => _loc.T("dash.gpu_memory");
    public string ActiveModelLabel => _loc.T("dash.active_model");
    public string QuickActions => _loc.T("dash.quick_actions");
    public string ScanModelsBtn => _loc.T("dash.scan_models");
    public string DiscoverGguf => _loc.T("dash.discover_gguf");
    public string CreateProfileBtn => _loc.T("dash.create_profile");
    public string LaunchConfig => _loc.T("dash.launch_config");
    public string CheckUpdatesBtn => _loc.T("dash.check_updates");
    public string LlamaVersionLabel => _loc.T("dash.llama_version");

    public DashboardViewModel(
        IServerManager serverManager,
        IModelScanner modelScanner,
        IProfileManager profileManager,
        ISettings settings,
        INavigationService navigation,
        ILocalizationService loc)
    {
        _serverManager = serverManager;
        _modelScanner = modelScanner;
        _profileManager = profileManager;
        _settings = settings;
        _navigation = navigation;
        _loc = loc;

        _serverManager.StatusChanged += (s, status) => ServerStatus = status;
    }

    partial void OnServerStatusChanged(ServerStatus value)
    {
        EstimatedVramGb = value.VramUsedGb;
        VramPercentage = value.VramUsedGb > 0
            ? Math.Min(value.VramUsedGb / 24.0 * 100, 100)
            : 0;
        SelectedModel = value.ModelName ?? "No model selected";
    }

    [RelayCommand]
    void Navigate(string page)
    {
        _navigation.Navigate(page);
    }

    public async Task RefreshAsync()
    {
        ServerStatus = await _serverManager.GetStatusAsync();

        if (!string.IsNullOrWhiteSpace(_settings.ModelsDirectory) &&
            Directory.Exists(_settings.ModelsDirectory))
        {
            var models = await _modelScanner.ScanDirectoryAsync(_settings.ModelsDirectory);
            TotalModels = models.Count;
        }

        var profiles = await _profileManager.GetAllProfilesAsync();
        TotalProfiles = profiles.Count;

        var defaultProfile = await _profileManager.GetDefaultProfileAsync();
        SelectedModel = defaultProfile?.ModelPath != null
            ? Path.GetFileName(defaultProfile.ModelPath)
            : "No model selected";

        if (!string.IsNullOrWhiteSpace(_settings.ActiveLlamaCppVersion))
            ActiveVersion = _settings.ActiveLlamaCppVersion;

        EstimatedVramGb = ServerStatus.VramUsedGb;
        VramPercentage = ServerStatus.VramUsedGb > 0
            ? Math.Min(ServerStatus.VramUsedGb / 24.0 * 100, 100)
            : 0;
    }
}