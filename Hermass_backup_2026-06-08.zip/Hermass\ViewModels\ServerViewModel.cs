using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Hermass.Core.Enums;
using Hermass.Core.Interfaces;
using Hermass.Core.Models;
using System.Collections.ObjectModel;

namespace Hermass.ViewModels;

public partial class ServerViewModel : ObservableObject
{
    readonly IServerManager _serverManager;
    readonly IProfileManager _profileManager;
    readonly ISettings _settings;
    readonly ILogService _log;
    readonly IDialogService _dialog;
    readonly IModelScanner _scanner;
    readonly ILlamaUpdater _updater;
    readonly ILocalizationService _loc;

    // Translated strings
    public string Title => _loc.T("server.title");
    public string StartBtn => _loc.T("server.start_btn");
    public string StopBtn => _loc.T("server.stop_btn");
    public string HealthCheckBtn => _loc.T("server.health_check_btn");
    public string SaveProfileBtn => _loc.T("server.save_profile_btn");
    public string LoadProfileBtn => _loc.T("server.load_profile_btn");
    public string RefreshProfilesBtn => _loc.T("server.refresh_profiles_btn");
    public string ExportBatBtn => _loc.T("server.export_bat_btn");
    public string CopyCmdLineBtn => _loc.T("server.copy_cmdline_btn");
    public string NoProfileSelected => _loc.T("server.no_profile_selected");
    public string NoModelSelected => _loc.T("server.no_model_selected");
    public string BrowseModelBtn => _loc.T("server.browse_model_btn");
    public string BrowseMmprojBtn => _loc.T("server.browse_mmproj_btn");
    public string BrowseDraftBtn => _loc.T("server.browse_draft_btn");
    public string QuickScanBtn => _loc.T("server.quick_scan_btn");
    public string QuickSelectModelBtn => _loc.T("server.quick_select_model_btn");
    public string QuickSelectMmprojBtn => _loc.T("server.quick_select_mmproj_btn");
    public string QuickSelectDraftBtn => _loc.T("server.quick_select_draft_btn");
    public string CheckVersionBtn => _loc.T("server.check_version_btn");
    public string SelectLlamaDirBtn => _loc.T("server.select_llama_dir_btn");

    // Computed display text
    public string ExecutableFoundText => ExecutableFound ? $"Executable found: {ExecutablePath}" : "Executable not found";

    // ServerPage labels
    public string StateLabel => _loc.T("server.state_label");
    public string TabModel => _loc.T("server.tab_model");
    public string TabGpu => _loc.T("server.tab_gpu");
    public string TabContextSampling => _loc.T("server.tab_context_sampling");
    public string TabAdvanced => _loc.T("server.tab_advanced");
    public string TabConnection => _loc.T("server.tab_connection");
    public string ServerPathTitle => _loc.T("server.server_path_title");
    public string ExecHint => _loc.T("server.exec_hint");
    public string MainModelLabel => _loc.T("server.main_model");
    public string ModelWatermark => _loc.T("server.model_watermark");
    public string MmprojTitle => _loc.T("server.mmproj_title");
    public string OptionalBadge => _loc.T("server.optional");
    public string MmprojWatermark => _loc.T("server.mmproj_watermark");
    public string DraftTitle => _loc.T("server.draft_title");
    public string AdvancedBadge => _loc.T("server.advanced_badge");
    public string EnableSpeculative => _loc.T("server.enable_speculative");
    public string DraftWatermark => _loc.T("server.draft_watermark");
    public string QuickSelectTitle => _loc.T("server.quick_select_title");
    public string HfTitle => _loc.T("server.hf_title");
    public string DownloadToLabel => _loc.T("server.download_to_fmt");
    public string SelectThisModelBtn => _loc.T("server.select_this_model");
    public string OrManual => _loc.T("server.or_manual");
    public string RepoLabel => _loc.T("server.repo_label");
    public string OfflineMode => _loc.T("server.offline_mode");
    public string GpuAcceleration => _loc.T("server.gpu_acceleration");
    public string GpuLayersLabel => _loc.T("server.gpu_layers_label");
    public string ThreadsLabel => _loc.T("server.threads_label");
    public string ThreadsBatchLabel => _loc.T("server.threads_batch_label");
    public string MainGpuLabel => _loc.T("server.main_gpu_label");
    public string FlashAttentionCheck => _loc.T("server.flash_attention");
    public string MemoryMapCheck => _loc.T("server.memory_map");
    public string MlockCheck => _loc.T("server.mlock");
    public string NoMmqCheck => _loc.T("server.no_mmq");
    public string NoKvOffloadCheck => _loc.T("server.no_kv_offload");
    public string ContextBatchTitle => _loc.T("server.context_batch");
    public string ContextLabel => _loc.T("server.context_label");
    public string BatchLabel => _loc.T("server.batch_label");
    public string UbatchLabel => _loc.T("server.ubatch_label");
    public string MaxTokensLabel => _loc.T("server.max_tokens_label");
    public string SamplingTitle => _loc.T("server.sampling_title");
    public string TemperatureLabel => _loc.T("server.temperature_label");
    public string TopPLabel => _loc.T("server.top_p_label");
    public string TopKLabel => _loc.T("server.top_k_label");
    public string MinPLabel => _loc.T("server.min_p_label");
    public string TypicalPLabel => _loc.T("server.typical_p_label");
    public string RepeatPenaltyLabel => _loc.T("server.repeat_penalty_label");
    public string RepeatLastNLabel => _loc.T("server.repeat_last_n_label");
    public string PresencePenaltyLabel => _loc.T("server.presence_penalty_label");
    public string FrequencyPenaltyLabel => _loc.T("server.frequency_penalty_label");
    public string SeedLabel => _loc.T("server.seed_label");
    public string MirostatSamplingCheck => _loc.T("server.mirostat_sampling");
    public string TauLabel => _loc.T("server.tau_label");
    public string EtaLabel => _loc.T("server.eta_label");
    public string MtpTitle => _loc.T("server.mtp_title");
    public string EnableMtpCheck => _loc.T("server.enable_mtp");
    public string PredictCountLabel => _loc.T("server.predict_count_label");
    public string SpecDraftParamsTitle => _loc.T("server.spec_draft_params");
    public string DraftGpuLayersLabel => _loc.T("server.draft_gpu_layers_label");
    public string DraftNMaxLabel => _loc.T("server.draft_n_max_label");
    public string DraftNMinLabel => _loc.T("server.draft_n_min_label");
    public string DraftPSplitLabel => _loc.T("server.draft_p_split_label");
    public string DraftPMinLabel => _loc.T("server.draft_p_min_label");
    public string YarnRopeTitle => _loc.T("server.yarn_rope_title");
    public string RopeFreqBaseLabel => _loc.T("server.rope_freq_base_label");
    public string RopeFreqScaleLabel => _loc.T("server.rope_freq_scale_label");
    public string YarnOrigCtxLabel => _loc.T("server.yarn_orig_ctx_label");
    public string AdvancedOptionsTitle => _loc.T("server.advanced_options_title");
    public string NumaCheck => _loc.T("server.numa");
    public string CachePromptCheck => _loc.T("server.cache_prompt");
    public string ContBatchingCheck => _loc.T("server.cont_batching");
    public string VerboseLoggingCheck => _loc.T("server.verbose_logging");
    public string WebUICheck => _loc.T("server.web_ui");
    public string MetricsCheck => _loc.T("server.metrics");
    public string ReasoningCheck => _loc.T("server.reasoning");
    public string EmbeddingModeCheck => _loc.T("server.embedding_mode");
    public string CustomArgsTitle => _loc.T("server.custom_args_title");
    public string CustomArgsWatermark => _loc.T("server.custom_args_placeholder");
    public string ExportTitle => _loc.T("server.export_title");
    public string ConnectionSettingsTitle => _loc.T("server.connection_settings");
    public string HostLabel => _loc.T("server.host_label");
    public string PortLabel => _loc.T("server.port_label");
    public string TimeoutLabel => _loc.T("server.timeout_label");
    public string SlotsLabel => _loc.T("server.slots_label");
    public string ProfileControlsTitle => _loc.T("server.profile_controls");

    // Tooltips
    public string TipModelPath => "Путь к файлу модели для загрузки (-m). Поддерживает перетаскивание.";
    public string TipMmprojPath => "Путь к файлу мультимодального проектора для моделей зрения (--mmproj). Необходим для моделей вроде LLaVA.";
    public string TipDraftModelPath => "Черновая модель для спекулятивного декодирования (--spec-draft-model, -md)";
    public string TipGpuLayers => "Количество слоёв модели для выгрузки на GPU (-ngl). 0 = только CPU, -1 = все слои. По умолчанию: 0";
    public string TipThreads => "Количество потоков CPU для генерации (-t). Больше потоков = быстрее, но с убывающей отдачей.";
    public string TipThreadsBatch => "Количество потоков CPU для обработки батча (-tb). По умолчанию: равно -t.";
    public string TipMainGpu => "Основной GPU для вычислений (--main-gpu). Индекс GPU, начиная с 0.";
    public string TipFlashAttention => "Включить Flash Attention для более быстрого и экономичного по памяти вычисления внимания";
    public string TipMmap => "Использовать mmap для загрузки модели (--mmap). Отключить для медленной загрузки, но меньшего pageout. По умолчанию: включено";
    public string TipMlock => "Удерживать модель в RAM, предотвращая своппинг (--mlock)";
    public string TipNoMmq => "Отключить смешанное квантование KV-кэша (--no-mmq)";
    public string TipNoKvOffload => "Не выгружать KV-кэш на GPU (--no-kv-offload)";
    public string TipContextSize => "Размер контекста промпта в токенах (-c). Большие значения требуют больше RAM/VRAM. По умолчанию: 512";
    public string TipBatchSize => "Максимальное количество токенов, обрабатываемых за раз при оценке промпта (-b). По умолчанию: 2048";
    public string TipUBatchSize => "Физический размер батча для обработки (-ubatch). Должен быть ≤ размера батча. По умолчанию: 512";
    public string TipMaxTokens => "Максимальное количество токенов для генерации за ответ (-n). По умолчанию: 256";
    public string TipTemperature => "Управляет случайностью вывода (-temp). Выше = креативнее, ниже = точнее. По умолчанию: 0.8";
    public string TipTopP => "Порог nucleus-сэмплирования (--top-p). Оставляет токены с кумулятивной вероятностью ≤ P. По умолчанию: 0.95";
    public string TipTopK => "Ограничивает выбор токенов до K наиболее вероятных (--top-k). Меньше = меньше разнообразия. По умолчанию: 40";
    public string TipMinP => "Порог минимальной вероятности для сэмплирования токенов (--min-p). Отсеивает маловероятные токены. По умолчанию: 0.05";
    public string TipTypicalP => "Порог типичного сэмплирования (--typical-p). Значения < 1.0 увеличивают разнообразие. По умолчанию: 1.0";
    public string TipRepeatPenalty => "Штраф за повторение одинаковых токенов (--repeat-penalty). Значения > 1.0 уменьшают повторения. По умолчанию: 1.1";
    public string TipRepeatLastN => "Окно токенов для проверки повторений (--repeat-last-n). 0 = отключено, -1 = весь контекст. По умолчанию: 64";
    public string TipPresencePenalty => "Штраф за присутствие токена для уменьшения повторений (--presence-penalty). По умолчанию: 0.0";
    public string TipFrequencyPenalty => "Штраф за частоту токена для уменьшения повторений (--frequency-penalty). По умолчанию: 0.0";
    public string TipSeed => "Seed ГСЧ для воспроизводимости вывода (-s, --seed). -1=случайный";
    public string TipMirostat => "Адаптивный алгоритм сэмплирования Mirostat для контроля perplexity";
    public string TipTau => "Целевая perplexity для Mirostat (--mirostat-tau). По умолчанию: 5";
    public string TipEta => "Скорость обучения Mirostat (--mirostat-eta). По умолчанию: 0.1";
    public string TipEnableMtp => "Включить Multi-Token Prediction (MTP) для моделей с несколькими головками предсказания";
    public string TipPredictCount => "Количество токенов для предсказания за шаг (--predict-count). По умолчанию: авто.";
    public string TipSpecDraftGpuLayers => "Макс. число слоёв драфта в VRAM (-ngld). Число, 'auto' или 'all'. По умолчанию: auto";
    public string TipSpecDraftNMax => "Число токенов для драфта (--spec-draft-n-max). По умолчанию: 3";
    public string TipSpecDraftNMin => "Минимальное число токенов драфта (--spec-draft-n-min). По умолчанию: 0";
    public string TipSpecDraftPSplit => "Вероятность разделения (--spec-draft-p-split). По умолчанию: 0.10";
    public string TipSpecDraftPMin => "Минимальная вероятность (greedy) (--spec-draft-p-min). По умолчанию: 0.00";
    public string TipRopeFreqBase => "Базовая частота RoPE (--rope-freq-base). По умолчанию: из модели.";
    public string TipRopeFreqScale => "Масштаб RoPE (--rope-freq-scale). По умолчанию: из модели.";
    public string TipYarnOriginalContext => "Оригинальный размер контекста для YARN (--yarn-orig-ctx). По умолчанию: из модели.";
    public string TipNuma => "Включить NUMA-aware распределение памяти (--numa)";
    public string TipCachePrompt => "Кэшировать промпты для повторных запросов (--cache-prompt). По умолчанию: включено";
    public string TipContBatching => "Включить непрерывный батчинг (-cb). По умолчанию: включено";
    public string TipVerboseLogging => "Подробное логирование сервера (--verbose)";
    public string TipWebUI => "Включить встроенный веб-чат, доступный из браузера";
    public string TipMetrics => "Включить метрики в формате Prometheus на /metrics для мониторинга";
    public string TipReasoning => "Включить режим reasoning/мышления (-rea). По умолчанию: авто (определяется из модели)";
    public string TipEmbeddingMode => "Ограничить сервер режимом эмбеддинга. Отключает endpoint чат-генерации.";
    public string TipHost => "IP-адрес сервера. По умолчанию: 127.0.0.1 (только localhost). Используйте 0.0.0.0 для всех интерфейсов.";
    public string TipPort => "TCP-порт сервера. По умолчанию: 8080";
    public string TipTimeout => "Таймаут чтения/записи сервера в секундах (-to). По умолчанию: 600";
    public string TipSlots => "Количество параллельных слотов запросов (-np, --parallel). По умолчанию: авто (-1)";
    public string TipCustomArgs => "Любые дополнительные аргументы CLI llama-server, по одному на строку. Напр. --special-flag value";

    // Server state
    [ObservableProperty] ServerState _state = ServerState.Stopped;
    [ObservableProperty] double _vramUsedGb;
    [ObservableProperty] double _ramUsedGb;
    [ObservableProperty] double _tokensPerSecond;
    [ObservableProperty] int _queueSize;
    [ObservableProperty] int _activeSlots;
    [ObservableProperty] TimeSpan _uptime;
    [ObservableProperty] string _processId = "—";
    [ObservableProperty] string _errorMessage = string.Empty;

    // Profile selection
    [ObservableProperty] ObservableCollection<ServerProfile> _profiles = new();
    [ObservableProperty] ServerProfile? _selectedProfile;

    // Model paths
    [ObservableProperty] string _modelPath = string.Empty;
    [ObservableProperty] string _mmprojPath = string.Empty;
    [ObservableProperty] string _draftModelPath = string.Empty;
    [ObservableProperty] string _modelDisplayName = "No model selected";
    [ObservableProperty] string _mmprojDisplayName = "No mmproj selected";
    [ObservableProperty] string _draftDisplayName = "No draft model selected";

    // HuggingFace
    [ObservableProperty] string _hfRepo = string.Empty;
    [ObservableProperty] string _hfFile = string.Empty;
    [ObservableProperty] bool _hfOffline;
    [ObservableProperty] string _hfRepoDraft = string.Empty;
    [ObservableProperty] bool _isDownloadingHf;
    [ObservableProperty] double _hfDownloadProgress;
    [ObservableProperty] string _hfDownloadStatus = string.Empty;
    [ObservableProperty] string _hfDownloadDirectory = string.Empty;
    [ObservableProperty] string _modelDescription = string.Empty;
    [ObservableProperty] string _modelSizeInfo = string.Empty;
    [ObservableProperty] string _modelParamsInfo = string.Empty;

    // Recommended models for quick selection
    public ObservableCollection<RecommendedModel> RecommendedModels { get; } = new();

    partial void OnHfRepoChanged(string value)
    {
        var match = RecommendedModels.FirstOrDefault(m => m.Repo == value);
        if (match != null)
        {
            ModelDescription = match.Description;
            ModelSizeInfo = $"~{match.Size}";
            ModelParamsInfo = match.Params;
        }
        else
        {
            ModelDescription = string.Empty;
            ModelSizeInfo = string.Empty;
            ModelParamsInfo = string.Empty;
        }
    }

    partial void OnLlamaCppDirectoryChanged(string value)
    {
        UpdateExecutablePath();
    }

    // Connection
    [ObservableProperty] string _host = "127.0.0.1";
    [ObservableProperty] int _port = 8080;
    [ObservableProperty] int _timeout = 600;
    [ObservableProperty] int _slots = 4;

    // GPU
    [ObservableProperty] int _gpuLayers = 99;
    [ObservableProperty] int _threads;
    [ObservableProperty] int _threadsBatch;
    [ObservableProperty] bool _flashAttention = true;
    [ObservableProperty] bool _mmap = true;
    [ObservableProperty] bool _mlock;
    [ObservableProperty] bool _noMmq;
    [ObservableProperty] bool _noKvOffload;
    [ObservableProperty] int _mainGpu;
    [ObservableProperty] GpuSplitMode _gpuSplitMode;
    [ObservableProperty] string _tensorSplit = string.Empty;

    // Context & Batch
    [ObservableProperty] int _contextSize = 4096;
    [ObservableProperty] int _batchSize = 2048;
    [ObservableProperty] int _ubatchSize = 512;
    [ObservableProperty] int _maxTokens = 256;

    // Cache type
    [ObservableProperty] string _cacheTypeK = "f16";
    [ObservableProperty] string _cacheTypeV = "f16";

    // Sampling
    [ObservableProperty] float _temperature = 0.8f;
    [ObservableProperty] int _topK = 40;
    [ObservableProperty] float _topP = 0.95f;
    [ObservableProperty] float _minP = 0.05f;
    [ObservableProperty] float _typicalP = 1f;
    [ObservableProperty] float _repeatPenalty = 1.1f;
    [ObservableProperty] int _repeatLastN = 64;
    [ObservableProperty] float _presencePenalty;
    [ObservableProperty] float _frequencyPenalty;
    [ObservableProperty] int _seed = -1;

    // Mirostat
    [ObservableProperty] bool _mirostat;
    [ObservableProperty] float _mirostatTau = 5f;
    [ObservableProperty] float _mirostatEta = 0.1f;

    // DRY
    [ObservableProperty] float _dryMultiplier;
    [ObservableProperty] float _dryBase = 1.75f;

    // Dynatemp
    [ObservableProperty] float _dynatempStddev;

    // XTC
    [ObservableProperty] float _xtcProbability;
    [ObservableProperty] float _xtcThreshold = 0.1f;

    // MTP / Speculative
    [ObservableProperty] bool _enableMtp;
    [ObservableProperty] int _predictCount = -1;
    [ObservableProperty] bool _speculativeDecoding;
    [ObservableProperty] int _specDraftGpuLayers = -1;
    [ObservableProperty] int _specDraftNMax = 3;
    [ObservableProperty] int _specDraftNMin;
    [ObservableProperty] float _specDraftPSplit = 0.1f;
    [ObservableProperty] float _specDraftPMin = 0.0f;

    // Advanced
    [ObservableProperty] bool _embeddingMode;
    [ObservableProperty] string _poolingType = string.Empty;
    [ObservableProperty] bool _numa;
    [ObservableProperty] string _processPriority = "Normal";
    [ObservableProperty] bool _cachePrompt = true;
    [ObservableProperty] bool _contBatching;
    [ObservableProperty] bool _verboseLogging;
    [ObservableProperty] bool _enableWebUI;
    [ObservableProperty] bool _enableSlots;
    [ObservableProperty] bool _enableMetrics;
    [ObservableProperty] bool _reasoning;
    [ObservableProperty] int _reasoningBudget;

    // Rope / YARN
    [ObservableProperty] double? _ropeFreqBase;
    [ObservableProperty] double? _ropeFreqScale;
    [ObservableProperty] int? _yarnOriginalContext;
    [ObservableProperty] double? _yarnExtFactor;
    [ObservableProperty] double? _yarnAttnFactor;
    [ObservableProperty] double? _yarnBetaFast;
    [ObservableProperty] double? _yarnBetaSlow;

    // Extra
    [ObservableProperty] string _apiKey = string.Empty;
    [ObservableProperty] string _alias = string.Empty;
    [ObservableProperty] string _additionalArgs = string.Empty;

    // Llama.cpp info
    [ObservableProperty] string _llamaCppDirectory = string.Empty;
    [ObservableProperty] string _executablePath = string.Empty;
    [ObservableProperty] bool _executableFound;
    [ObservableProperty] string _llamaVersionInfo = string.Empty;
    [ObservableProperty] string _cudaInfo = string.Empty;

    // Scanned models for quick selection
    [ObservableProperty] ObservableCollection<GgufModelInfo> _scannedModels = new();
    [ObservableProperty] GgufModelInfo? _quickSelectedModel;
    [ObservableProperty] bool _isScanningModels;

    public ServerViewModel(
        IServerManager serverManager,
        IProfileManager profileManager,
        ISettings settings,
        ILogService log,
        IDialogService dialog,
        IModelScanner scanner,
        ILlamaUpdater updater,
        ILocalizationService loc)
    {
        _serverManager = serverManager;
        _profileManager = profileManager;
        _settings = settings;
        _log = log;
        _dialog = dialog;
        _scanner = scanner;
        _updater = updater;
        _loc = loc;

        _serverManager.StatusChanged += OnStatusChanged;
        _loc.OnLanguageChanged += OnLanguageChanged;
        _profileManager.ProfileChanged += OnProfileChanged;
        Host = _settings.DefaultHost;
        Port = _settings.DefaultPort;
        GpuLayers = _settings.DefaultGpuLayers;
        FlashAttention = _settings.FlashAttention;
        LlamaCppDirectory = _settings.LlamaCppDirectory;
        HfDownloadDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".cache\\huggingface\\hub");

        UpdateExecutablePath();
        PopulateRecommendedModels();
        _ = LoadProfilesAsync();
    }

    async void OnProfileChanged(string profileId)
    {
        var profile = await _profileManager.GetProfileAsync(profileId);
        if (profile != null && SelectedProfile?.Id == profileId)
        {
            ApplyProfileToSettings(profile);
        }
    }

    void OnLanguageChanged(object? sender, string language)
    {
        // Trigger PropertyChanged for all translated properties
        foreach (var prop in new[]
        {
            nameof(Title), nameof(StartBtn), nameof(StopBtn), nameof(HealthCheckBtn), nameof(SaveProfileBtn), nameof(LoadProfileBtn),
            nameof(RefreshProfilesBtn), nameof(ExportBatBtn), nameof(CopyCmdLineBtn), nameof(NoProfileSelected),
            nameof(NoModelSelected), nameof(BrowseModelBtn), nameof(BrowseMmprojBtn), nameof(BrowseDraftBtn),
            nameof(QuickScanBtn), nameof(QuickSelectModelBtn), nameof(QuickSelectMmprojBtn), nameof(QuickSelectDraftBtn),
            nameof(CheckVersionBtn), nameof(SelectLlamaDirBtn), nameof(StateLabel), nameof(TabModel), nameof(TabGpu),
            nameof(TabContextSampling), nameof(TabAdvanced), nameof(TabConnection), nameof(ServerPathTitle),
            nameof(ExecHint), nameof(MainModelLabel), nameof(ModelWatermark), nameof(MmprojTitle), nameof(OptionalBadge),
            nameof(MmprojWatermark), nameof(DraftTitle), nameof(AdvancedBadge), nameof(EnableSpeculative),
            nameof(DraftWatermark), nameof(QuickSelectTitle), nameof(HfTitle), nameof(DownloadToLabel),
            nameof(SelectThisModelBtn), nameof(OrManual), nameof(RepoLabel), nameof(OfflineMode),
            nameof(GpuAcceleration), nameof(GpuLayersLabel), nameof(ThreadsLabel), nameof(ThreadsBatchLabel),
            nameof(MainGpuLabel), nameof(FlashAttentionCheck), nameof(MemoryMapCheck), nameof(MlockCheck),
            nameof(NoMmqCheck), nameof(NoKvOffloadCheck), nameof(ContextBatchTitle), nameof(ContextLabel),
            nameof(BatchLabel), nameof(UbatchLabel), nameof(MaxTokensLabel), nameof(SamplingTitle),
            nameof(TemperatureLabel), nameof(TopPLabel), nameof(TopKLabel), nameof(MinPLabel), nameof(TypicalPLabel),
            nameof(RepeatPenaltyLabel), nameof(RepeatLastNLabel), nameof(PresencePenaltyLabel), nameof(FrequencyPenaltyLabel),
            nameof(SeedLabel), nameof(MirostatSamplingCheck), nameof(TauLabel), nameof(EtaLabel), nameof(MtpTitle),
            nameof(EnableMtpCheck), nameof(PredictCountLabel), nameof(SpecDraftParamsTitle), nameof(DraftGpuLayersLabel),
            nameof(DraftNMaxLabel), nameof(DraftNMinLabel), nameof(DraftPSplitLabel), nameof(DraftPMinLabel),
            nameof(YarnRopeTitle), nameof(RopeFreqBaseLabel), nameof(RopeFreqScaleLabel), nameof(YarnOrigCtxLabel),
            nameof(AdvancedOptionsTitle), nameof(NumaCheck), nameof(CachePromptCheck), nameof(ContBatchingCheck),
            nameof(VerboseLoggingCheck), nameof(WebUICheck), nameof(MetricsCheck), nameof(ReasoningCheck),
            nameof(EmbeddingModeCheck), nameof(CustomArgsTitle), nameof(CustomArgsWatermark), nameof(ExportTitle),
            nameof(ConnectionSettingsTitle), nameof(HostLabel), nameof(PortLabel), nameof(TimeoutLabel),
            nameof(SlotsLabel), nameof(ProfileControlsTitle)
        })
            OnPropertyChanged(prop);
    }

    void PopulateRecommendedModels()
    {
        RecommendedModels.Add(new("bartowski/Llama-4-Maverick-17B-128E-Instruct-Q4_K_M.gguf", "Llama 4 Maverick 17B", "Q4_K_M", "~9.5 GB", "17B params, 128K context"));
        RecommendedModels.Add(new("bartowski/Llama-3.3-70B-Instruct-Q4_K_M.gguf", "Llama 3.3 70B Instruct", "Q4_K_M", "~43 GB", "70B params, general purpose"));
        RecommendedModels.Add(new("bartowski/Qwen2.5-Coder-32B-Instruct-Q4_K_M.gguf", "Qwen 2.5 Coder 32B", "Q4_K_M", "~20 GB", "32B params, code generation"));
        RecommendedModels.Add(new("bartowski/Mistral-Nemo-12B-Instruct-Q4_K_M.gguf", "Mistral Nemo 12B", "Q4_K_M", "~7.5 GB", "12B params, multilingual"));
        RecommendedModels.Add(new("bartowski/Llama-3.1-8B-Instruct-Q4_K_M.gguf", "Llama 3.1 8B Instruct", "Q4_K_M", "~5.5 GB", "8B params, lightweight"));
    }

    [RelayCommand]
    void SelectRecommendedModel(RecommendedModel model)
    {
        HfRepo = model.Repo;
    }

    void UpdateExecutablePath()
    {
        ExecutablePath = Path.Combine(LlamaCppDirectory, "llama-server.exe");
        ExecutableFound = File.Exists(ExecutablePath);
    }

    partial void OnSelectedProfileChanged(ServerProfile? value)
    {
        if (value != null)
            ApplyProfileToSettings(value);
    }

    async Task LoadProfilesAsync()
    {
        Profiles.Clear();
        var list = await _profileManager.GetAllProfilesAsync();
        foreach (var p in list)
            Profiles.Add(p);

        var defaultProfile = await _profileManager.GetDefaultProfileAsync();
        SelectedProfile = defaultProfile ?? Profiles.FirstOrDefault();
    }

    void ApplyProfileToSettings(ServerProfile profile)
    {
        // Model paths
        ModelPath = profile.ModelPath ?? string.Empty;
        MmprojPath = profile.MmprojPath ?? string.Empty;
        DraftModelPath = profile.DraftModelPath ?? string.Empty;
        UpdateDisplayNames();

        // HuggingFace
        HfRepo = profile.HfRepo ?? string.Empty;
        HfFile = profile.HfFile ?? string.Empty;
        HfOffline = profile.HfOffline;
        HfRepoDraft = profile.HfRepoDraft ?? string.Empty;

        // Connection
        Host = profile.Host;
        Port = profile.Port;
        Timeout = profile.Timeout;
        Slots = profile.Slots;

        // GPU
        GpuLayers = profile.GpuLayers;
        Threads = profile.Threads;
        ThreadsBatch = profile.ThreadsBatch;
        FlashAttention = profile.FlashAttention;
        Mmap = profile.Mmap;
        Mlock = profile.Mlock;
        NoMmq = profile.NoMmq;
        NoKvOffload = profile.NoKvOffload;
        MainGpu = profile.MainGpu;
        GpuSplitMode = profile.GpuSplitMode;
        TensorSplit = string.Join(",", profile.TensorSplit);

        // Context & Batch
        ContextSize = profile.ContextSize;
        BatchSize = profile.BatchSize;
        UbatchSize = profile.UbatchSize;
        MaxTokens = profile.MaxTokens;

        // Cache type
        CacheTypeK = profile.CacheTypeK.ToString().ToLower();
        CacheTypeV = profile.CacheTypeV.ToString().ToLower();

        // Sampling
        Temperature = profile.Temperature;
        TopK = profile.TopK;
        TopP = profile.TopP;
        MinP = profile.MinP;
        TypicalP = profile.TypicalP;
        RepeatPenalty = profile.RepeatPenalty;
        RepeatLastN = profile.RepeatLastN;
        PresencePenalty = profile.PresencePenalty;
        FrequencyPenalty = profile.FrequencyPenalty;
        Seed = profile.Seed;

        // Mirostat
        Mirostat = profile.Mirostat;
        MirostatTau = profile.MirostatTau;
        MirostatEta = profile.MirostatEta;

        // DRY
        DryMultiplier = profile.DryMultiplier;
        DryBase = profile.DryBase;

        // Dynatemp
        DynatempStddev = profile.DynatempStddev;

        // XTC
        XtcProbability = profile.XtcProbability;
        XtcThreshold = profile.XtcThreshold;

        // MTP / Speculative
        EnableMtp = profile.EnableMtp;
        PredictCount = profile.PredictCount;
        SpeculativeDecoding = profile.SpeculativeDecoding;
        SpecDraftGpuLayers = profile.SpecDraftGpuLayers;
        SpecDraftNMax = profile.SpecDraftNMax;
        SpecDraftNMin = profile.SpecDraftNMin;
        SpecDraftPSplit = profile.SpecDraftPSplit;
        SpecDraftPMin = profile.SpecDraftPMin;

        // Advanced
        EmbeddingMode = profile.EmbeddingMode;
        PoolingType = profile.PoolingType;
        Numa = profile.Numa;
        ProcessPriority = profile.ProcessPriority;
        CachePrompt = true;
        ContBatching = profile.ContBatching;
        VerboseLogging = profile.VerboseLogging;
        EnableWebUI = profile.EnableWebUI;
        EnableSlots = profile.EnableSlots;
        EnableMetrics = profile.EnableMetrics;
        Reasoning = profile.Reasoning;
        ReasoningBudget = profile.ReasoningBudget;

        // Rope / YARN
        RopeFreqBase = profile.RopeFreqBase;
        RopeFreqScale = profile.RopeFreqScale;
        YarnOriginalContext = profile.YarnOriginalContext;
        YarnExtFactor = profile.YarnExtFactor;
        YarnAttnFactor = profile.YarnAttnFactor;
        YarnBetaFast = profile.YarnBetaFast;
        YarnBetaSlow = profile.YarnBetaSlow;

        // Extra
        ApiKey = profile.ApiKey ?? string.Empty;
        Alias = profile.Alias ?? string.Empty;
        AdditionalArgs = profile.AdditionalArgs;
    }

    void UpdateDisplayNames()
    {
        ModelDisplayName = string.IsNullOrWhiteSpace(ModelPath)
            ? "No model selected"
            : Path.GetFileName(ModelPath);
        MmprojDisplayName = string.IsNullOrWhiteSpace(MmprojPath)
            ? "No mmproj selected"
            : Path.GetFileName(MmprojPath);
        DraftDisplayName = string.IsNullOrWhiteSpace(DraftModelPath)
            ? "No draft model selected"
            : Path.GetFileName(DraftModelPath);
    }

    /// <summary>
    /// Called from ModelsPage when user clicks "Use in Server"
    /// </summary>
    public void SetModelFromScanner(GgufModelInfo model)
    {
        if (model == null) return;
        ModelPath = model.Path;
        UpdateDisplayNames();

        if (SelectedProfile != null)
        {
            SelectedProfile.ModelPath = model.Path;
            _ = _profileManager.SaveProfileAsync(SelectedProfile);
        }

        _log.Information($"Model set from scanner: {model.FileName}", "Server");
    }

    /// <summary>
    /// Called from ModelsPage when user clicks "Use as mmproj"
    /// </summary>
    public void SetMmprojFromScanner(GgufModelInfo model)
    {
        if (model == null) return;
        MmprojPath = model.Path;
        UpdateDisplayNames();

        if (SelectedProfile != null)
        {
            SelectedProfile.MmprojPath = model.Path;
            _ = _profileManager.SaveProfileAsync(SelectedProfile);
        }

        _log.Information($"mmproj set from scanner: {model.FileName}", "Server");
    }

    /// <summary>
    /// Called from ModelsPage when user clicks "Use as draft model"
    /// </summary>
    public void SetDraftModelFromScanner(GgufModelInfo model)
    {
        if (model == null) return;
        DraftModelPath = model.Path;
        UpdateDisplayNames();

        if (SelectedProfile != null)
        {
            SelectedProfile.DraftModelPath = model.Path;
            _ = _profileManager.SaveProfileAsync(SelectedProfile);
        }

        _log.Information($"Draft model set from scanner: {model.FileName}", "Server");
    }

    void OnStatusChanged(object? sender, ServerStatus status)
    {
        State = status.State;
        VramUsedGb = status.VramUsedGb;
        RamUsedGb = status.RamUsedGb;
        TokensPerSecond = status.TokensPerSecond;
        QueueSize = status.QueueSize;
        ActiveSlots = status.ActiveSlots;
        Uptime = status.Uptime;
        ProcessId = status.ProcessId?.ToString() ?? "—";
        ErrorMessage = status.ErrorMessage ?? string.Empty;
    }

    #region Model Browse Commands

    [RelayCommand]
    async Task BrowseModel()
    {
        var path = await _dialog.SelectFileAsync(
            "Select GGUF Model",
            ModelPath,
            "GGUF Files|*.gguf|All Files|*.*");

        if (!string.IsNullOrEmpty(path) && File.Exists(path))
        {
            ModelPath = path;
            UpdateDisplayNames();
            _log.Information($"Model selected: {path}", "Server");
        }
    }

    [RelayCommand]
    async Task BrowseMmproj()
    {
        var path = await _dialog.SelectFileAsync(
            "Select mmproj Model",
            MmprojPath,
            "GGUF Files|*.gguf|All Files|*.*");

        if (!string.IsNullOrEmpty(path) && File.Exists(path))
        {
            MmprojPath = path;
            UpdateDisplayNames();
            _log.Information($"mmproj selected: {path}", "Server");
        }
    }

    [RelayCommand]
    async Task BrowseDraftModel()
    {
        var path = await _dialog.SelectFileAsync(
            "Select Draft Model",
            DraftModelPath,
            "GGUF Files|*.gguf|All Files|*.*");

        if (!string.IsNullOrEmpty(path) && File.Exists(path))
        {
            DraftModelPath = path;
            UpdateDisplayNames();
            _log.Information($"Draft model selected: {path}", "Server");
        }
    }

    #endregion

    #region Quick Model Scan

    [RelayCommand]
    async Task QuickScanModels()
    {
        var dir = string.IsNullOrWhiteSpace(_settings.ModelsDirectory)
            ? LlamaCppDirectory
            : _settings.ModelsDirectory;

        if (!Directory.Exists(dir))
        {
            var selected = await _dialog.SelectFolderAsync("Select Models Directory", dir);
            if (string.IsNullOrEmpty(selected) || !Directory.Exists(selected))
                return;
            dir = selected;
        }

        IsScanningModels = true;
        ScannedModels.Clear();

        try
        {
            var results = await _scanner.ScanDirectoryAsync(dir);
            foreach (var m in results)
                ScannedModels.Add(m);

            _log.Information($"Quick scan: {results.Count} models found", "Server");
        }
        catch (Exception ex)
        {
            _log.Error(ex, "Quick scan failed", "Server");
        }
        finally
        {
            IsScanningModels = false;
        }
    }

    [RelayCommand]
    void QuickSelectModel()
    {
        if (QuickSelectedModel != null)
        {
            ModelPath = QuickSelectedModel.Path;
            UpdateDisplayNames();
            _log.Information($"Quick-selected model: {QuickSelectedModel.FileName}", "Server");
        }
    }

    [RelayCommand]
    void QuickSelectMmproj()
    {
        if (QuickSelectedModel != null)
        {
            MmprojPath = QuickSelectedModel.Path;
            UpdateDisplayNames();
            _log.Information($"Quick-selected mmproj: {QuickSelectedModel.FileName}", "Server");
        }
    }

    [RelayCommand]
    void QuickSelectDraft()
    {
        if (QuickSelectedModel != null)
        {
            DraftModelPath = QuickSelectedModel.Path;
            UpdateDisplayNames();
            _log.Information($"Quick-selected draft: {QuickSelectedModel.FileName}", "Server");
        }
    }

    #endregion

    #region Server Control

    [RelayCommand]
    public async Task StartServerAsync()
    {
        if (SelectedProfile == null)
        {
            ErrorMessage = "No profile selected.";
            State = ServerState.Error;
            return;
        }

        if (string.IsNullOrWhiteSpace(ModelPath))
        {
            ErrorMessage = "No model selected.";
            _log.Error(ErrorMessage, "Server");
            State = ServerState.Error;
            return;
        }

        var exePath = ExecutablePath;
        if (!File.Exists(exePath))
        {
            ErrorMessage = $"llama-server.exe not found: {exePath}";
            _log.Error(ErrorMessage, "Server");
            State = ServerState.Error;
            return;
        }

        // Sync UI values to profile before starting
        SyncSettingsToProfile();

        try
        {
            _log.Information($"Starting server with profile: {SelectedProfile.Name}", "Server");
            await _serverManager.StartAsync(SelectedProfile);
        }
        catch (Exception ex)
        {
            ErrorMessage = ex.Message;
            _log.Error(ex, "Failed to start server", "Server");
            State = ServerState.Error;
        }
    }

    [RelayCommand]
    async Task StopServer()
    {
        try
        {
            _log.Information("Stopping server...", "Server");
            await _serverManager.StopAsync();
        }
        catch (Exception ex)
        {
            ErrorMessage = ex.Message;
            _log.Error(ex, "Failed to stop server", "Server");
            State = ServerState.Error;
        }
    }

    [RelayCommand]
    async Task HealthCheck()
    {
        var status = await _serverManager.HealthCheckAsync(Host, Port);
        State = status.State;
        ErrorMessage = status.ErrorMessage ?? string.Empty;
    }

    #endregion

    #region Profile Management

    [RelayCommand]
    async Task SaveToProfile()
    {
        if (SelectedProfile == null)
        {
            _log.Error("No profile selected to save settings.", "Server");
            return;
        }

        SyncSettingsToProfile();
        await _profileManager.SaveProfileAsync(SelectedProfile);
        _log.Information($"Settings saved to profile: {SelectedProfile.Name}", "Server");
    }

    [RelayCommand]
    async Task RefreshProfiles()
    {
        await LoadProfilesAsync();
    }

    [RelayCommand]
    void LoadProfile()
    {
        if (SelectedProfile == null)
        {
            _log.Error("No profile selected to load.", "Server");
            return;
        }
        ApplyProfileToSettings(SelectedProfile);
        _log.Information($"Profile loaded: {SelectedProfile.Name}", "Server");
    }

    #endregion

    #region Llama.cpp Info

    [RelayCommand]
    async Task CheckLlamaCppVersion()
    {
        if (!ExecutableFound)
        {
            LlamaVersionInfo = "llama-server.exe not found";
            CudaInfo = string.Empty;
            return;
        }

        try
        {
            var releases = await _updater.FetchReleasesAsync(false);
            var installedTag = DetectInstalledVersion();

            LlamaVersionInfo = installedTag ?? "Unknown version";

            if (releases != null && releases.Count > 0)
            {
                var latest = releases[0].TagName;
                if (installedTag != null && installedTag != latest)
                    LlamaVersionInfo += $" (latest: {latest})";
            }

            CudaInfo = DetectCudaSupport();
        }
        catch (Exception ex)
        {
            LlamaVersionInfo = $"Error checking version: {ex.Message}";
            _log.Error(ex, "Failed to check llama.cpp version", "Server");
        }
    }

    [RelayCommand]
    async Task SelectLlamaCppDirectory()
    {
        var path = await _dialog.SelectFolderAsync(
            "Select llama.cpp Directory",
            LlamaCppDirectory);

        if (!string.IsNullOrEmpty(path) && Directory.Exists(path))
        {
            LlamaCppDirectory = path;
            _settings.LlamaCppDirectory = path;
            await _settings.SaveAsync();
            UpdateExecutablePath();
            _log.Information($"llama.cpp directory set: {path}", "Server");
        }
    }

    string? DetectInstalledVersion()
    {
        if (!ExecutableFound) return null;

        var dir = Path.GetDirectoryName(ExecutablePath)!;
        var ggmlVersionFile = Path.Combine(dir, "ggml-version.txt");
        if (File.Exists(ggmlVersionFile))
            return File.ReadAllText(ggmlVersionFile).Trim();

        var exeVersion = System.Diagnostics.FileVersionInfo.GetVersionInfo(ExecutablePath);
        if (!string.IsNullOrEmpty(exeVersion.ProductVersion))
            return exeVersion.ProductVersion;

        return "Installed (version unknown)";
    }

    string DetectCudaSupport()
    {
        if (!ExecutableFound) return "N/A";

        var dir = Path.GetDirectoryName(ExecutablePath)!;
        var cudaDlls = Directory.GetFiles(dir, "cudart*.dll");
        var cublasDlls = Directory.GetFiles(dir, "cublas*.dll");

        if (cudaDlls.Length > 0 || cublasDlls.Length > 0)
            return $"CUDA DLLs found: {cudaDlls.Length + cublasDlls.Length} files";

        var exeName = Path.GetFileName(ExecutablePath).ToLower();
        if (exeName.Contains("cuda") || exeName.Contains("cuBLAS"))
            return "CUDA build (by executable name)";

        return "CPU build (no CUDA DLLs detected)";
    }

    #endregion

    #region Export

    [RelayCommand]
    async Task ExportToBat()
    {
        if (SelectedProfile == null)
        {
            _log.Error("No profile selected to export.", "Server");
            return;
        }

        SyncSettingsToProfile();
        var args = BuildCommandLinePreview(SelectedProfile);
        var batContent = $"@echo off\r\ncd /d \"{Path.GetDirectoryName(ExecutablePath)}\"\r\n{Path.GetFileName(ExecutablePath)} {args}\r\npause";

        var path = await _dialog.SaveFileAsync(
            "Export as Batch File",
            $"{SelectedProfile.Name}.bat",
            "Batch Files|*.bat|All Files|*.*");

        if (!string.IsNullOrEmpty(path))
        {
            File.WriteAllText(path, batContent);
            _log.Information($"Exported to: {path}", "Server");
        }
    }

    [RelayCommand]
    void CopyCommandLine()
    {
        if (SelectedProfile == null) return;

        SyncSettingsToProfile();
        var args = BuildCommandLinePreview(SelectedProfile);
        var fullCommand = $"\"{ExecutablePath}\" {args}";

        _log.Information($"Command line: {fullCommand}", "Server");
    }

    string BuildCommandLinePreview(ServerProfile profile)
    {
        var args = new List<string>();

        if (!string.IsNullOrEmpty(profile.ModelPath))
        {
            args.Add("-m");
            args.Add($"\"{profile.ModelPath}\"");
        }

        if (!string.IsNullOrEmpty(profile.MmprojPath))
        {
            args.Add("--mmproj");
            args.Add($"\"{profile.MmprojPath}\"");
        }

        if (!string.IsNullOrEmpty(profile.DraftModelPath) && profile.SpeculativeDecoding)
        {
            args.Add("-m");
            args.Add($"\"{profile.DraftModelPath}\"");
        }

        args.Add($"--gpu-layers {profile.GpuLayers}");
        args.Add($"--ctx-size {profile.ContextSize}");
        args.Add($"--batch-size {profile.BatchSize}");
        args.Add($"--ubatch-size {profile.UbatchSize}");

        if (profile.Threads > 0)
            args.Add($"--threads {profile.Threads}");

        if (profile.FlashAttention)
            args.Add("--flash-attn");

        args.Add(profile.Mmap ? "--mmap" : "--no-mmap");

        args.Add($"--host {profile.Host}");
        args.Add($"--port {profile.Port}");
        args.Add($"--timeout {profile.Timeout}");

        if (!string.IsNullOrEmpty(profile.AdditionalArgs))
            args.Add(profile.AdditionalArgs);

        return string.Join(" ", args);
    }

    #endregion

    #region Settings Sync

    public void SyncSettingsToProfile()
    {
        if (SelectedProfile == null) return;

        SelectedProfile.ModelPath = string.IsNullOrWhiteSpace(ModelPath) ? null : ModelPath;
        SelectedProfile.MmprojPath = string.IsNullOrWhiteSpace(MmprojPath) ? null : MmprojPath;
        SelectedProfile.DraftModelPath = string.IsNullOrWhiteSpace(DraftModelPath) ? null : DraftModelPath;

        // HuggingFace
        SelectedProfile.HfRepo = string.IsNullOrWhiteSpace(HfRepo) ? null : HfRepo;
        SelectedProfile.HfFile = string.IsNullOrWhiteSpace(HfFile) ? null : HfFile;
        SelectedProfile.HfOffline = HfOffline;
        SelectedProfile.HfRepoDraft = string.IsNullOrWhiteSpace(HfRepoDraft) ? null : HfRepoDraft;

        // Connection
        SelectedProfile.Host = Host;
        SelectedProfile.Port = Port;
        SelectedProfile.Timeout = Timeout;
        SelectedProfile.Slots = Slots;

        // GPU
        SelectedProfile.GpuLayers = GpuLayers;
        SelectedProfile.Threads = Threads;
        SelectedProfile.ThreadsBatch = ThreadsBatch;
        SelectedProfile.FlashAttention = FlashAttention;
        SelectedProfile.Mmap = Mmap;
        SelectedProfile.Mlock = Mlock;
        SelectedProfile.NoMmq = NoMmq;
        SelectedProfile.NoKvOffload = NoKvOffload;
        SelectedProfile.MainGpu = MainGpu;
        SelectedProfile.GpuSplitMode = GpuSplitMode;
        SelectedProfile.TensorSplit = string.IsNullOrWhiteSpace(TensorSplit)
            ? Array.Empty<int>()
            : TensorSplit.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Select(int.Parse).ToArray();

        // Context & Batch
        SelectedProfile.ContextSize = ContextSize;
        SelectedProfile.BatchSize = BatchSize;
        SelectedProfile.UbatchSize = UbatchSize;
        SelectedProfile.MaxTokens = MaxTokens;

        // Cache type
        SelectedProfile.CacheTypeK = ParseCacheTypeK(CacheTypeK);
        SelectedProfile.CacheTypeV = ParseCacheTypeV(CacheTypeV);

        // Sampling
        SelectedProfile.Temperature = Temperature;
        SelectedProfile.TopK = TopK;
        SelectedProfile.TopP = TopP;
        SelectedProfile.MinP = MinP;
        SelectedProfile.TypicalP = TypicalP;
        SelectedProfile.RepeatPenalty = RepeatPenalty;
        SelectedProfile.RepeatLastN = RepeatLastN;
        SelectedProfile.PresencePenalty = PresencePenalty;
        SelectedProfile.FrequencyPenalty = FrequencyPenalty;
        SelectedProfile.Seed = Seed;

        // Mirostat
        SelectedProfile.Mirostat = Mirostat;
        SelectedProfile.MirostatTau = MirostatTau;
        SelectedProfile.MirostatEta = MirostatEta;

        // DRY
        SelectedProfile.DryMultiplier = DryMultiplier;
        SelectedProfile.DryBase = DryBase;

        // Dynatemp
        SelectedProfile.DynatempStddev = DynatempStddev;

        // XTC
        SelectedProfile.XtcProbability = XtcProbability;
        SelectedProfile.XtcThreshold = XtcThreshold;

        // MTP / Speculative
        SelectedProfile.EnableMtp = EnableMtp;
        SelectedProfile.PredictCount = PredictCount;
        SelectedProfile.SpeculativeDecoding = SpeculativeDecoding;
        SelectedProfile.SpecDraftGpuLayers = SpecDraftGpuLayers;
        SelectedProfile.SpecDraftNMax = SpecDraftNMax;
        SelectedProfile.SpecDraftNMin = SpecDraftNMin;
        SelectedProfile.SpecDraftPSplit = SpecDraftPSplit;
        SelectedProfile.SpecDraftPMin = SpecDraftPMin;

        // Advanced
        SelectedProfile.EmbeddingMode = EmbeddingMode;
        SelectedProfile.PoolingType = PoolingType;
        SelectedProfile.Numa = Numa;
        SelectedProfile.ProcessPriority = ProcessPriority;
        SelectedProfile.ContBatching = ContBatching;
        SelectedProfile.VerboseLogging = VerboseLogging;
        SelectedProfile.EnableWebUI = EnableWebUI;
        SelectedProfile.EnableSlots = EnableSlots;
        SelectedProfile.EnableMetrics = EnableMetrics;
        SelectedProfile.Reasoning = Reasoning;
        SelectedProfile.ReasoningBudget = ReasoningBudget;

        // Rope / YARN
        SelectedProfile.RopeFreqBase = RopeFreqBase;
        SelectedProfile.RopeFreqScale = RopeFreqScale;
        SelectedProfile.YarnOriginalContext = YarnOriginalContext;
        SelectedProfile.YarnExtFactor = YarnExtFactor;
        SelectedProfile.YarnAttnFactor = YarnAttnFactor;
        SelectedProfile.YarnBetaFast = YarnBetaFast;
        SelectedProfile.YarnBetaSlow = YarnBetaSlow;

        // Extra
        SelectedProfile.ApiKey = string.IsNullOrWhiteSpace(ApiKey) ? null : ApiKey;
        SelectedProfile.Alias = string.IsNullOrWhiteSpace(Alias) ? null : Alias;
        SelectedProfile.AdditionalArgs = AdditionalArgs;
        SelectedProfile.UpdatedAt = DateTime.Now;
    }

    static Core.Enums.CacheTypeK ParseCacheTypeK(string value)
    {
        return value.ToLower() switch
        {
            "f16" => Core.Enums.CacheTypeK.F16,
            "f32" => Core.Enums.CacheTypeK.F32,
            "q8_0" => Core.Enums.CacheTypeK.Q8_0,
            "q4_0" => Core.Enums.CacheTypeK.Q4_0,
            _ => Core.Enums.CacheTypeK.F16
        };
    }

    static Core.Enums.CacheTypeV ParseCacheTypeV(string value)
    {
        return value.ToLower() switch
        {
            "f16" => Core.Enums.CacheTypeV.F16,
            "f32" => Core.Enums.CacheTypeV.F32,
            "q8_0" => Core.Enums.CacheTypeV.Q8_0,
            "q4_0" => Core.Enums.CacheTypeV.Q4_0,
            _ => Core.Enums.CacheTypeV.F16
        };
    }

    #endregion
}

public sealed class RecommendedModel
{
    public string Repo { get; }
    public string Name { get; }
    public string Quantization { get; }
    public string Size { get; }
    public string Params { get; }
    public string Description { get; }

    public RecommendedModel(string repo, string name, string quantization, string size, string description)
    {
        Repo = repo;
        Name = name;
        Quantization = quantization;
        Size = size;
        Params = description;
        Description = $"{name} | {quantization}";
    }
}
