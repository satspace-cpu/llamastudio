using System.Text.Json.Serialization;
using Hermass.Core.Enums;

namespace Hermass.Core.Models;

public class ServerProfile
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..8];

    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;

    [JsonPropertyName("description")]
    public string Description { get; set; } = string.Empty;

    [JsonPropertyName("modelPath")]
    public string? ModelPath { get; set; }

    [JsonPropertyName("mmprojPath")]
    public string? MmprojPath { get; set; }

    [JsonPropertyName("draftModelPath")]
    public string? DraftModelPath { get; set; }

    [JsonPropertyName("llamaCppVersion")]
    public string? LlamaCppVersion { get; set; }

    // HuggingFace download
    [JsonPropertyName("hfRepo")]
    public string? HfRepo { get; set; }

    [JsonPropertyName("hfFile")]
    public string? HfFile { get; set; }

    [JsonPropertyName("hfOffline")]
    public bool HfOffline { get; set; }

    [JsonPropertyName("hfRepoDraft")]
    public string? HfRepoDraft { get; set; }

    // Speculative draft parameters
    [JsonPropertyName("specDraftGpuLayers")]
    public int SpecDraftGpuLayers { get; set; } = -1;

    [JsonPropertyName("specDraftNMax")]
    public int SpecDraftNMax { get; set; } = 3;

    [JsonPropertyName("specDraftNMin")]
    public int SpecDraftNMin { get; set; } = 0;

    [JsonPropertyName("specDraftPSplit")]
    public float SpecDraftPSplit { get; set; } = 0.1f;

    [JsonPropertyName("specDraftPMin")]
    public float SpecDraftPMin { get; set; } = 0.0f;

    // Extra server options from reference
    [JsonPropertyName("apiKey")]
    public string? ApiKey { get; set; }

    [JsonPropertyName("alias")]
    public string? Alias { get; set; }

    [JsonPropertyName("logFilePath")]
    public string? LogFilePath { get; set; }

    [JsonPropertyName("verboseLogging")]
    public bool VerboseLogging { get; set; }

    [JsonPropertyName("enableWebUI")]
    public bool EnableWebUI { get; set; }

    [JsonPropertyName("enableSlots")]
    public bool EnableSlots { get; set; }

    [JsonPropertyName("enableMetrics")]
    public bool EnableMetrics { get; set; }

    [JsonPropertyName("reasoning")]
    public bool Reasoning { get; set; }

    [JsonPropertyName("reasoningBudget")]
    public int ReasoningBudget { get; set; }

    [JsonPropertyName("seed")]
    public int Seed { get; set; } = -1;

    [JsonPropertyName("presencePenalty")]
    public float PresencePenalty { get; set; }

    [JsonPropertyName("frequencyPenalty")]
    public float FrequencyPenalty { get; set; }

    [JsonPropertyName("maxTokens")]
    public int MaxTokens { get; set; } = 256;

    [JsonPropertyName("cachePrompt")]
    public bool CachePrompt { get; set; } = true;

    [JsonPropertyName("contBatching")]
    public bool ContBatching { get; set; }

    [JsonPropertyName("gpuLayers")]
    public int GpuLayers { get; set; } = 99;

    [JsonPropertyName("gpuSplitMode")]
    public GpuSplitMode GpuSplitMode { get; set; }

    [JsonPropertyName("tensorSplit")]
    public int[] TensorSplit { get; set; } = Array.Empty<int>();

    [JsonPropertyName("mainGpu")]
    public int MainGpu { get; set; }

    [JsonPropertyName("flashAttention")]
    public bool FlashAttention { get; set; } = true;

    [JsonPropertyName("mmap")]
    public bool Mmap { get; set; } = true;

    [JsonPropertyName("mlock")]
    public bool Mlock { get; set; }

    [JsonPropertyName("noMmq")]
    public bool NoMmq { get; set; }

    [JsonPropertyName("noKvOffload")]
    public bool NoKvOffload { get; set; }

    [JsonPropertyName("contextSize")]
    public int ContextSize { get; set; } = 4096;

    [JsonPropertyName("batchSize")]
    public int BatchSize { get; set; } = 2048;

    [JsonPropertyName("ubatchSize")]
    public int UbatchSize { get; set; } = 512;

    [JsonPropertyName("cacheTypeK")]
    public CacheTypeK CacheTypeK { get; set; }

    [JsonPropertyName("cacheTypeV")]
    public CacheTypeV CacheTypeV { get; set; }

    [JsonPropertyName("threads")]
    public int Threads { get; set; } = 0;

    [JsonPropertyName("threadsBatch")]
    public int ThreadsBatch { get; set; } = 0;

    [JsonPropertyName("temperature")]
    public float Temperature { get; set; } = 0.8f;

    [JsonPropertyName("topK")]
    public int TopK { get; set; } = 40;

    [JsonPropertyName("topP")]
    public float TopP { get; set; } = 0.95f;

    [JsonPropertyName("minP")]
    public float MinP { get; set; } = 0.05f;

    [JsonPropertyName("typicalP")]
    public float TypicalP { get; set; } = 1.0f;

    [JsonPropertyName("repeatPenalty")]
    public float RepeatPenalty { get; set; } = 1.1f;

    [JsonPropertyName("repeatLastN")]
    public int RepeatLastN { get; set; } = 64;

    [JsonPropertyName("mirostat")]
    public bool Mirostat { get; set; }

    [JsonPropertyName("mirostatTau")]
    public float MirostatTau { get; set; } = 5.0f;

    [JsonPropertyName("mirostatEta")]
    public float MirostatEta { get; set; } = 0.1f;

    [JsonPropertyName("dryMultiplier")]
    public float DryMultiplier { get; set; }

    [JsonPropertyName("dryBase")]
    public float DryBase { get; set; } = 1.75f;

    [JsonPropertyName("dynatempStddev")]
    public float DynatempStddev { get; set; }

    [JsonPropertyName("xtcProbability")]
    public float XtcProbability { get; set; }

    [JsonPropertyName("xtcThreshold")]
    public float XtcThreshold { get; set; } = 0.1f;

    [JsonPropertyName("host")]
    public string Host { get; set; } = "127.0.0.1";

    [JsonPropertyName("port")]
    public int Port { get; set; } = 8080;

    [JsonPropertyName("timeout")]
    public int Timeout { get; set; } = 600;

    [JsonPropertyName("slots")]
    public int Slots { get; set; } = 4;

    [JsonPropertyName("predictCount")]
    public int PredictCount { get; set; } = -1;

    [JsonPropertyName("enableMtp")]
    public bool EnableMtp { get; set; }

    [JsonPropertyName("speculativeDecoding")]
    public bool SpeculativeDecoding { get; set; }

    [JsonPropertyName("ropeFreqBase")]
    public double? RopeFreqBase { get; set; }

    [JsonPropertyName("ropeFreqScale")]
    public double? RopeFreqScale { get; set; }

    [JsonPropertyName("yarnOriginalContext")]
    public int? YarnOriginalContext { get; set; }

    [JsonPropertyName("yarnExtFactor")]
    public double? YarnExtFactor { get; set; }

    [JsonPropertyName("yarnAttnFactor")]
    public double? YarnAttnFactor { get; set; }

    [JsonPropertyName("yarnBetaFast")]
    public double? YarnBetaFast { get; set; }

    [JsonPropertyName("yarnBetaSlow")]
    public double? YarnBetaSlow { get; set; }

    [JsonPropertyName("embeddingMode")]
    public bool EmbeddingMode { get; set; }

    [JsonPropertyName("poolingType")]
    public string PoolingType { get; set; } = string.Empty;

    [JsonPropertyName("processPriority")]
    public string ProcessPriority { get; set; } = "Normal";

    [JsonPropertyName("numa")]
    public bool Numa { get; set; }

    [JsonPropertyName("cpuAffinity")]
    public string? CpuAffinity { get; set; }

    [JsonPropertyName("additionalArgs")]
    public string AdditionalArgs { get; set; } = string.Empty;

    [JsonPropertyName("createdAt")]
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    [JsonPropertyName("updatedAt")]
    public DateTime UpdatedAt { get; set; } = DateTime.Now;

    [JsonPropertyName("isDefault")]
    public bool IsDefault { get; set; }

    [JsonPropertyName("color")]
    public string Color { get; set; } = "#3B82F6";
}
