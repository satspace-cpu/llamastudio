using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Hermass.Core.Interfaces;
using Hermass.Core.Models;
using Hermass.Views.Pages;
using Avalonia.Controls;

namespace Hermass.ViewModels;

public partial class MainViewModel : ObservableObject
{
    readonly IServerManager _serverManager;
    readonly IProfileManager _profileManager;
    readonly ISettings _settings;
    readonly ILogService _log;
    readonly ILocalizationService _loc;
    readonly DashboardViewModel _dashboard;
    readonly ModelsViewModel _models;
    readonly ServerViewModel _server;
    readonly ProfilesViewModel _profiles;
    readonly LogsViewModel _logs;
    readonly SettingsViewModel _settingsVm;

    [ObservableProperty] string _selectedPage = "Dashboard";
    [ObservableProperty] Control? _currentPage;
    [ObservableProperty] bool _canStartServer = true;
    [ObservableProperty] bool _canStopServer = false;

    // Translated strings for MainWindow
    public string NavDashboard => _loc.T("main.dashboard");
    public string NavModels => _loc.T("main.models");
    public string NavServer => _loc.T("main.server");
    public string NavProfiles => _loc.T("main.profiles");
    public string NavLogs => _loc.T("main.logs");
    public string NavSettings => _loc.T("main.settings");
    public string BtnStartServer => _loc.T("main.start_server");
    public string BtnStopServer => _loc.T("main.stop_server");
    public string Subtitle => _loc.T("main.subtitle");

    public MainViewModel(
        IServerManager serverManager,
        IProfileManager profileManager,
        ISettings settings,
        ILogService log,
        ILocalizationService loc,
        DashboardViewModel dashboard,
        ModelsViewModel models,
        ServerViewModel server,
        ProfilesViewModel profiles,
        LogsViewModel logs,
        SettingsViewModel settingsVm)
    {
        _serverManager = serverManager;
        _profileManager = profileManager;
        _settings = settings;
        _log = log;
        _loc = loc;
        _dashboard = dashboard;
        _models = models;
        _server = server;
        _profiles = profiles;
        _logs = logs;
        _settingsVm = settingsVm;

        _serverManager.StatusChanged += OnServerStatusChanged;
        _loc.OnLanguageChanged += OnLanguageChanged;
        NavigateTo("Dashboard");
        _ = InitializeAsync();
    }

    void OnLanguageChanged(object? sender, string language)
    {
        OnPropertyChanged(nameof(NavDashboard));
        OnPropertyChanged(nameof(NavModels));
        OnPropertyChanged(nameof(NavServer));
        OnPropertyChanged(nameof(NavProfiles));
        OnPropertyChanged(nameof(NavLogs));
        OnPropertyChanged(nameof(NavSettings));
        OnPropertyChanged(nameof(BtnStartServer));
        OnPropertyChanged(nameof(BtnStopServer));
        OnPropertyChanged(nameof(Subtitle));
    }

    async Task InitializeAsync()
    {
        try
        {
            await _profiles.LoadProfilesAsync();

            var defaultProfile = await _profileManager.GetDefaultProfileAsync();
            if (defaultProfile == null)
            {
                var newProfile = new ServerProfile
                {
                    Name = "Default",
                    Description = "Default server profile",
                    IsDefault = true
                };
                await _profileManager.SaveProfileAsync(newProfile);
                await _profiles.LoadProfilesAsync();
                _log.Information("Created default profile", "Main");
            }

            await _dashboard.RefreshAsync();

            if (!string.IsNullOrWhiteSpace(_settings.ModelsDirectory) &&
                Directory.Exists(_settings.ModelsDirectory))
            {
                await _models.ScanModels();
            }

            _log.Information("Application initialized", "Main");
        }
        catch (Exception ex)
        {
            _log.Error(ex, "Initialization failed", "Main");
        }
    }

    public void NavigateTo(string page)
    {
        try
        {
            if (SelectedPage == page && CurrentPage != null)
                return;

            SelectedPage = page;

            if (page == "Dashboard")
                _ = _dashboard.RefreshAsync();

            Control ctrl = page switch
            {
                "Dashboard" => new DashboardPage(_dashboard),
                "Models" => new ModelsPage(_models),
                "Server" => new ServerPage(_server),
                "Profiles" => new ProfilesPage(_profiles),
                "Logs" => new LogsPage(_logs),
                "Settings" => new SettingsPage(_settingsVm),
                _ => new DashboardPage(_dashboard)
            };
            CurrentPage = ctrl;
        }
        catch (Exception ex)
        {
            _log.Error(ex, $"NavigateTo({page}) failed", "Main");
        }
    }

    [RelayCommand]
    void Navigate(string page)
    {
        try
        {
            NavigateTo(page);
        }
        catch (Exception ex)
        {
            _log.Error(ex, $"NavigateCommand({page}) failed", "Main");
        }
    }

    [RelayCommand]
    async Task StartServer()
    {
        try
        {
            var defaultProfile = await _profileManager.GetDefaultProfileAsync();
            if (defaultProfile == null)
            {
                _log.Error("No default profile found. Create a profile first.", "UI");
                return;
            }

            if (string.IsNullOrWhiteSpace(defaultProfile.ModelPath))
            {
                _log.Error("Default profile has no model selected.", "UI");
                return;
            }

            await _serverManager.StartAsync(defaultProfile);
            _log.Information("Server started", "UI");
        }
        catch (Exception ex)
        {
            _log.Error(ex, "Failed to start server", "UI");
        }
    }

    [RelayCommand]
    async Task StopServer()
    {
        try
        {
            await _serverManager.StopAsync();
            _log.Information("Server stopped", "UI");
        }
        catch (Exception ex)
        {
            _log.Error(ex, "Failed to stop server", "UI");
        }
    }

    void OnServerStatusChanged(object? sender, ServerStatus status)
    {
        CanStopServer = status.State == Core.Enums.ServerState.Running ||
                        status.State == Core.Enums.ServerState.Starting;
        CanStartServer = status.State == Core.Enums.ServerState.Stopped ||
                         status.State == Core.Enums.ServerState.Error;
    }
}
