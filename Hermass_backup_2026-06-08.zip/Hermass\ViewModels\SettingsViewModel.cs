using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Hermass.Core.Interfaces;
using Hermass.Core.Models;
using System.Collections.ObjectModel;

namespace Hermass.ViewModels;

public partial class SettingsViewModel : ObservableObject, IDisposable
{
    readonly ISettings _settings;
    readonly ILogService _log;
    readonly ILlamaUpdater _updater;
    readonly IDialogService _dialog;
    readonly ILocalizationService _loc;
    System.Timers.Timer? _autoSaveTimer;
    bool _isDisposing;

    [ObservableProperty] string _llamaCppDirectory;
    [ObservableProperty] string _modelsDirectory;
    [ObservableProperty] string _activeVersion;
    [ObservableProperty] string _theme = "Dark";
    [ObservableProperty] bool _autoCheckUpdates = true;
    [ObservableProperty] bool _portableMode = true;
    [ObservableProperty] string _defaultHost = "127.0.0.1";
    [ObservableProperty] int _defaultPort = 8080;
    [ObservableProperty] int _defaultGpuLayers = 99;
    [ObservableProperty] bool _flashAttention = true;
    [ObservableProperty] Core.Enums.UpdateChannel _updateChannel = Core.Enums.UpdateChannel.Stable;
    [ObservableProperty] string _selectedLanguage = "en";
    [ObservableProperty] bool _isCheckingUpdates;
    [ObservableProperty] string _updateStatus = "Not checked";
    [ObservableProperty] ObservableCollection<LlamaCppRelease> _releases = new();
    [ObservableProperty] ObservableCollection<ReleaseBuildCard> _releaseBuildCards = new();
    [ObservableProperty] double _downloadProgress;
    [ObservableProperty] string _downloadStatus = string.Empty;

    public string[] LanguageOptions => new[] { "en", "ru" };
    public string[] ThemeOptions => new[] { "Dark", "Light", "System" };

    // Text wrappers for port/gpu layers (TextBox binding instead of NumericUpDown)
    [ObservableProperty] string _defaultPortText = "8080";
    [ObservableProperty] string _defaultGpuLayersText = "99";

    partial void OnDefaultPortTextChanged(string value)
    {
        if (int.TryParse(value, out var port) && port >= 1 && port <= 65535)
            DefaultPort = port;
    }

    partial void OnDefaultGpuLayersTextChanged(string value)
    {
        if (int.TryParse(value, out var layers) && layers >= 0 && layers <= 999)
            DefaultGpuLayers = layers;
    }

    partial void OnDefaultPortChanged(int value)
    {
        ResetAutoSave();
        if (DefaultPortText != value.ToString())
            DefaultPortText = value.ToString();
    }

    partial void OnDefaultGpuLayersChanged(int value)
    {
        ResetAutoSave();
        if (DefaultGpuLayersText != value.ToString())
            DefaultGpuLayersText = value.ToString();
    }

    // Translated strings
    public string Title => _loc.T("settings.title");
    public string GeneralSection => _loc.T("settings.general_section");
    public string LanguageLabel => _loc.T("settings.language_label");
    public string ThemeLabel => _loc.T("settings.theme_label");
    public string AutoCheckUpdatesLabel => _loc.T("settings.auto_check_updates");
    public string PortableModeLabel => _loc.T("settings.portable_mode");
    public string PathsSection => _loc.T("settings.paths_section");
    public string LlamaCppDirLabel => _loc.T("settings.llama_cpp_dir_label");
    public string ModelsDirLabel => _loc.T("settings.models_dir_label");
    public string BrowseBtn => _loc.T("settings.browse_btn");
    public string ServerDefaultsSection => _loc.T("settings.server_defaults_section");
    public string HostLabel => _loc.T("settings.host_label");
    public string PortLabel => _loc.T("settings.port_label");
    public string GpuLayersLabel => _loc.T("settings.gpu_layers_label");
    public string FlashAttentionLabel => _loc.T("settings.flash_attention");
    public string UpdatesSection => _loc.T("settings.releases");
    public string UpdateChannelLabel => _loc.T("settings.update_channel_label");
    public string CheckUpdatesBtn => _loc.T("settings.check_updates_btn");
    public string CheckingStatus => _loc.T("settings.checking_status");
    public string SaveSettingsBtn => _loc.T("settings.save_settings_btn");
    public string DarkTheme => _loc.T("settings.dark");
    public string LightTheme => _loc.T("settings.light");
    public string SystemTheme => _loc.T("settings.system");
    public string StableChannel => _loc.T("settings.stable");
    public string PrereleaseChannel => _loc.T("settings.prerelease");
    public string NightlyChannel => _loc.T("settings.nightly");
    public string RussianLanguage => _loc.T("settings.russian");
    public string EnglishLanguage => _loc.T("settings.english");
    public string InstallBtn => _loc.T("settings.install_btn");
    public string InstallingBtn => _loc.T("settings.installing_btn");

    // ToolTips
    public string TtLanguage => _loc.T("tt.language");
    public string TtLlamaCppDir => _loc.T("tt.llama_cpp_dir");
    public string TtModelsDir => _loc.T("tt.models_dir");
    public string TtAutoCheckUpdates => _loc.T("tt.auto_check_updates");
    public string TtPortableMode => _loc.T("tt.portable_mode");
    public string TtTheme => _loc.T("tt.theme");
    public string TtUpdateChannel => _loc.T("tt.update_channel");
    public string TtHost => _loc.T("tt.host");
    public string TtHostDefault => _loc.T("tt.host_default");
    public string TtPort => _loc.T("tt.port");
    public string TtPortManual => _loc.T("tt.port_manual");
    public string TtGpuLayers => _loc.T("tt.gpu_layers");
    public string TtGpuLayersDefault => _loc.T("tt.gpu_layers_default");
    public string TtFlashAttention => _loc.T("tt.flash_attention");
    public string TtInstallBuild => _loc.T("tt.install_build");

    public SettingsViewModel(ISettings settings, ILogService log, ILlamaUpdater updater, IDialogService dialog, ILocalizationService loc)
    {
        _settings = settings;
        _log = log;
        _updater = updater;
        _dialog = dialog;
        _loc = loc;

        LlamaCppDirectory = _settings.LlamaCppDirectory;
        ModelsDirectory = _settings.ModelsDirectory;
        ActiveVersion = _settings.ActiveLlamaCppVersion;
        Theme = _settings.Theme;
        AutoCheckUpdates = _settings.AutoCheckUpdates;
        PortableMode = _settings.PortableMode;
        DefaultHost = _settings.DefaultHost;
        DefaultPort = _settings.DefaultPort;
        DefaultPortText = _settings.DefaultPort.ToString();
        DefaultGpuLayers = _settings.DefaultGpuLayers;
        DefaultGpuLayersText = _settings.DefaultGpuLayers.ToString();
        FlashAttention = _settings.FlashAttention;
        UpdateChannel = _settings.UpdateChannel;
        SelectedLanguage = _loc.Language;

        _updater.DownloadProgress += (s, progress) => DownloadProgress = progress;
        _updater.StatusMessage += (s, msg) => DownloadStatus = msg;
        _loc.OnLanguageChanged += OnLanguageChanged;

        // Auto-save timer — saves settings 1 second after last change
        _autoSaveTimer = new System.Timers.Timer(1000) { AutoReset = false };
        _autoSaveTimer.Elapsed += (s, e) => _ = SaveSettingsInternalAsync();
    }

    void OnLanguageChanged(object? sender, string language)
    {
        foreach (var prop in new[]
        {
            nameof(Title), nameof(GeneralSection), nameof(LanguageLabel), nameof(ThemeLabel),
            nameof(AutoCheckUpdatesLabel), nameof(PortableModeLabel), nameof(PathsSection),
            nameof(LlamaCppDirLabel), nameof(ModelsDirLabel), nameof(BrowseBtn),
            nameof(ServerDefaultsSection), nameof(HostLabel), nameof(PortLabel), nameof(GpuLayersLabel),
            nameof(FlashAttentionLabel), nameof(UpdatesSection), nameof(UpdateChannelLabel),
            nameof(CheckUpdatesBtn), nameof(CheckingStatus), nameof(SaveSettingsBtn),
            nameof(DarkTheme), nameof(LightTheme), nameof(SystemTheme),
            nameof(StableChannel), nameof(PrereleaseChannel), nameof(NightlyChannel),
            nameof(RussianLanguage), nameof(EnglishLanguage), nameof(InstallBtn), nameof(InstallingBtn),
            nameof(TtLanguage), nameof(TtLlamaCppDir), nameof(TtModelsDir), nameof(TtAutoCheckUpdates),
            nameof(TtPortableMode), nameof(TtTheme), nameof(TtUpdateChannel), nameof(TtHost),
            nameof(TtHostDefault), nameof(TtPort), nameof(TtPortManual), nameof(TtGpuLayers),
            nameof(TtGpuLayersDefault), nameof(TtFlashAttention), nameof(TtInstallBuild)
        })
            OnPropertyChanged(prop);
    }

    partial void OnLlamaCppDirectoryChanged(string value) => ResetAutoSave();
    partial void OnModelsDirectoryChanged(string value) => ResetAutoSave();
    partial void OnThemeChanged(string value)
    {
        ResetAutoSave();
        ApplyTheme(value);
    }

    static void ApplyTheme(string? theme)
    {
        var app = Avalonia.Application.Current;
        if (app == null) return;

        app.RequestedThemeVariant = theme switch
        {
            "Light" => Avalonia.Styling.ThemeVariant.Light,
            "Dark" => Avalonia.Styling.ThemeVariant.Dark,
            _ => Avalonia.Styling.ThemeVariant.Default
        };
    }
    partial void OnAutoCheckUpdatesChanged(bool value) => ResetAutoSave();
    partial void OnPortableModeChanged(bool value) => ResetAutoSave();
    partial void OnDefaultHostChanged(string value) => ResetAutoSave();
    partial void OnFlashAttentionChanged(bool value) => ResetAutoSave();
    partial void OnUpdateChannelChanged(Core.Enums.UpdateChannel value) => ResetAutoSave();
    partial void OnSelectedLanguageChanged(string value)
    {
        if (!string.IsNullOrEmpty(value))
        {
            _loc.ChangeLanguage(value);
            _log.Information($"Language changed to: {value}", "Settings");
        }
    }

    void ResetAutoSave()
    {
        _autoSaveTimer?.Stop();
        _autoSaveTimer?.Start();
    }

    async Task SaveSettingsInternalAsync()
    {
        if (_isDisposing) return;

        ApplySettingsToModel();
        await _settings.SaveAsync();
        _log.Information("Settings auto-saved", "Settings");
    }

    void ApplySettingsToModel()
    {
        _settings.LlamaCppDirectory = LlamaCppDirectory;
        _settings.ModelsDirectory = ModelsDirectory;
        _settings.ActiveLlamaCppVersion = ActiveVersion;
        _settings.Theme = Theme;
        _settings.AutoCheckUpdates = AutoCheckUpdates;
        _settings.PortableMode = PortableMode;
        _settings.DefaultHost = DefaultHost;
        _settings.DefaultPort = DefaultPort;
        _settings.DefaultGpuLayers = DefaultGpuLayers;
        _settings.FlashAttention = FlashAttention;
        _settings.UpdateChannel = UpdateChannel;
    }

    public void Dispose()
    {
        _isDisposing = true;
        _autoSaveTimer?.Stop();
        _autoSaveTimer?.Dispose();
        _autoSaveTimer = null;
    }

    [RelayCommand]
    async Task SaveSettings()
    {
        _autoSaveTimer?.Stop();
        ApplySettingsToModel();
        await _settings.SaveAsync();
        _log.Information("Settings saved manually", "Settings");
    }

    [RelayCommand]
    async Task CheckForUpdates()
    {
        IsCheckingUpdates = true;
        UpdateStatus = "Checking for updates...";
        Releases.Clear();
        ReleaseBuildCards.Clear();

        try
        {
            var releases = await _updater.FetchReleasesAsync(UpdateChannel != Core.Enums.UpdateChannel.Stable);

            foreach (var r in releases)
            {
                Releases.Add(r);

                // Flatten: each asset becomes its own card
                foreach (var asset in r.Assets)
                {
                    _log.Information($"Build card: tag={r.TagName}, type={asset.BuildType}, desc=\"{asset.Description}\", name={asset.Name}", "Settings");
                    ReleaseBuildCards.Add(new ReleaseBuildCard
                    {
                        ReleaseTag = r.TagName,
                        ReleaseDate = r.PublishedAt,
                        IsPrerelease = r.IsPrerelease,
                        Asset = asset,
                        BuildType = asset.BuildType,
                        BuildDescription = asset.Description,
                        SizeDisplay = asset.SizeDisplay,
                        AssetName = asset.Name,
                        InstallBtnText = InstallBtn
                    });
                }
            }

            UpdateStatus = releases.Count > 0
                ? $"Latest: {releases[0].TagName}"
                : "No releases found";
        }
        catch (Exception ex)
        {
            UpdateStatus = $"Error: {ex.Message}";
            _log.Error(ex, "Update check failed", "Settings");
        }
        finally
        {
            IsCheckingUpdates = false;
        }
    }

    [RelayCommand]
    async Task InstallBuild(ReleaseBuildCard card)
    {
        try
        {
            // Disable button for this card
            card.InstallBtnText = InstallingBtn;

            DownloadStatus = $"Downloading {card.ReleaseTag} ({card.BuildDescription})...";
            DownloadProgress = 0;

            var targetDir = string.IsNullOrWhiteSpace(LlamaCppDirectory)
                ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "HermassLlamaServer")
                : LlamaCppDirectory;

            // Pass the specific asset to download
            var installPath = await _updater.DownloadAndExtractAsync(card.ReleaseTag, targetDir, card.Asset);

            // Auto-update paths
            LlamaCppDirectory = targetDir;
            ActiveVersion = card.ReleaseTag;
            _settings.LlamaCppDirectory = targetDir;
            _settings.ActiveLlamaCppVersion = ActiveVersion;
            await _settings.SaveAsync();

            DownloadStatus = $"Installed: {card.ReleaseTag} ({card.BuildDescription})";
            DownloadProgress = 100;
            card.InstallBtnText = "✓ Installed";
            _log.Information($"Installed: {card.ReleaseTag} ({card.BuildDescription})", "Settings");
        }
        catch (Exception ex)
        {
            DownloadStatus = $"Error: {ex.Message}";
            card.InstallBtnText = InstallBtn;
            _log.Error(ex, "Download failed", "Settings");
        }
    }

    [RelayCommand]
    async Task SelectLlamaCppDirectory()
    {
        var path = await _dialog.SelectFolderAsync("Select llama.cpp Directory", LlamaCppDirectory);
        if (!string.IsNullOrEmpty(path))
        {
            LlamaCppDirectory = path;
            _settings.LlamaCppDirectory = path;
            await _settings.SaveAsync();
        }
    }

    [RelayCommand]
    async Task SelectModelsDirectory()
    {
        var path = await _dialog.SelectFolderAsync("Select Models Directory", ModelsDirectory);
        if (!string.IsNullOrEmpty(path))
        {
            ModelsDirectory = path;
            _settings.ModelsDirectory = path;
            await _settings.SaveAsync();
        }
    }
}

// Flat card: one per asset, for the ListBox
public class ReleaseBuildCard
{
    public string ReleaseTag { get; set; } = string.Empty;
    public DateTime ReleaseDate { get; set; }
    public bool IsPrerelease { get; set; }
    public ReleaseAsset Asset { get; set; } = null!;
    public BuildType BuildType { get; set; }
    public string BuildDescription { get; set; } = string.Empty;
    public string SizeDisplay { get; set; } = string.Empty;
    public string AssetName { get; set; } = string.Empty;
    public string InstallBtnText { get; set; } = "Install";
}
