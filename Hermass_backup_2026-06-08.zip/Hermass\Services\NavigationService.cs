using Hermass.Core.Interfaces;
using Hermass.ViewModels;

namespace Hermass.Services;

public class NavigationService : INavigationService
{
    readonly Func<MainViewModel> _mainFactory;

    public NavigationService(Func<MainViewModel> mainFactory)
    {
        _mainFactory = mainFactory;
    }

    public void Navigate(string page)
    {
        _mainFactory().NavigateTo(page);
    }
}