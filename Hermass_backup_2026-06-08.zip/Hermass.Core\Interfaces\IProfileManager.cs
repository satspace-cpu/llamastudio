using Hermass.Core.Models;

namespace Hermass.Core.Interfaces;

public interface IProfileManager
{
    event Action<string>? ProfileChanged;

    Task<List<ServerProfile>> GetAllProfilesAsync();
    Task<ServerProfile?> GetProfileAsync(string id);
    Task<string> SaveProfileAsync(ServerProfile profile);
    Task<bool> DeleteProfileAsync(string id);
    Task<ServerProfile> DuplicateProfileAsync(string id);
    Task<ServerProfile> ImportProfileAsync(string json);
    string ExportProfile(ServerProfile profile);
    Task SetDefaultProfileAsync(string id);
    Task<ServerProfile?> GetDefaultProfileAsync();
}
