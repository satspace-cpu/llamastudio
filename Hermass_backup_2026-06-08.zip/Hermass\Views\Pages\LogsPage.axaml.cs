using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using Hermass.ViewModels;

namespace Hermass.Views.Pages;

public partial class LogsPage : UserControl
{
    public LogsPage()
    {
        InitializeComponent();
    }

    public LogsPage(LogsViewModel viewModel) : this()
    {
        this.DataContext = viewModel;
    }

    void InitializeComponent()
    {
        AvaloniaXamlLoader.Load(this);
    }
}
