using Avalonia.Controls;
using Avalonia.Platform.Storage;
using Hermass.Controls;
using Hermass.Core.Interfaces;

namespace Hermass.Services;

public class DialogService : IDialogService
{
    readonly Func<Window> _windowFactory;
    Window? _window;

    public DialogService(Func<Window> windowFactory)
    {
        _windowFactory = windowFactory;
    }

    Window Window => _window ??= _windowFactory();

    public async Task<string?> SelectFolderAsync(string title, string? initialPath = null)
    {
        var folders = await Window.StorageProvider.OpenFolderPickerAsync(new FolderPickerOpenOptions
        {
            Title = title,
            AllowMultiple = false
        });

        return folders.Count > 0 ? folders[0].Path.LocalPath : null;
    }

    public async Task<string?> SelectFileAsync(string title, string? initialPath = null, string? filter = null)
    {
        var files = await Window.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
        {
            Title = title,
            AllowMultiple = false
        });

        return files.Count > 0 ? files[0].Path.LocalPath : null;
    }

    public async Task<string?> SaveFileAsync(string title, string? initialPath = null, string? filter = null)
    {
        var file = await Window.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
        {
            Title = title,
        });

        return file?.Path.LocalPath;
    }

    public async Task ShowMessageAsync(string message, string? title = null)
    {
        var dialog = new MessageDialogWindow
        {
            Title = title ?? "Information",
            Message = message,
            ButtonType = MessageBoxButton.Ok
        };
        await dialog.ShowDialog(Window);
    }

    public async Task<bool> ShowConfirmationAsync(string message, string? title = null)
    {
        var dialog = new MessageDialogWindow
        {
            Title = title ?? "Confirmation",
            Message = message,
            ButtonType = MessageBoxButton.YesNo
        };
        await dialog.ShowDialog(Window);
        return dialog.Result == MessageBoxButtonResult.Yes;
    }

    public async Task ShowErrorAsync(string message, string? title = null)
    {
        var dialog = new MessageDialogWindow
        {
            Title = title ?? "Error",
            Message = message,
            ButtonType = MessageBoxButton.Ok
        };
        await dialog.ShowDialog(Window);
    }

    public async Task ShowSuccessAsync(string message, string? title = null)
    {
        var dialog = new MessageDialogWindow
        {
            Title = title ?? "Success",
            Message = message,
            ButtonType = MessageBoxButton.Ok
        };
        await dialog.ShowDialog(Window);
    }

    public async Task<string?> ShowInputAsync(string title, string message, string defaultValue = "")
    {
        var dialog = new InputDialogWindow
        {
            Title = title,
            Message = message,
            DefaultValue = defaultValue
        };
        await dialog.ShowDialog(Window);
        return dialog.ResultConfirmed ? dialog.ResultText : null;
    }
}
