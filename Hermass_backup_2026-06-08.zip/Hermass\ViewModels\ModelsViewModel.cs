using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Hermass.Core.Interfaces;
using Hermass.Core.Models;
using System.Collections.ObjectModel;

namespace Hermass.ViewModels;

public partial class ModelsViewModel : ObservableObject
{
    readonly IModelScanner _scanner;
    readonly ISettings _settings;
    readonly ILogService _log;
    readonly IDialogService _dialog;
    readonly IProfileManager _profileManager;
    readonly ILocalizationService _loc;

    [ObservableProperty] ObservableCollection<GgufModelInfo> _models = new();
    [ObservableProperty] GgufModelInfo? _selectedModel;
    [ObservableProperty] string _modelsDirectory;
    [ObservableProperty] bool _isScanning;
    [ObservableProperty] string _scanStatus = "Ready";
    [ObservableProperty] string _searchFilter = "";
    [ObservableProperty] int _filteredCount;

    // Translated strings
    public string Title => _loc.T("models.title");
    public string CountLabel => _loc.T("models.count");
    public string ScanBtn => _loc.T("models.scan");
    public string ScanningStatus => _loc.T("models.scanning");
    public string BrowseBtn => _loc.T("models.browse");
    public string SearchPlaceholder => _loc.T("models.search");
    public string NoModelsText => _loc.T("models.no_models");
    public string UseDefaultProfile => _loc.T("models.use_default_profile");
    public string ToServerModel => _loc.T("models.to_server");
    public string ToMmproj => _loc.T("models.to_mmproj");
    public string ToDraft => _loc.T("models.to_draft");

    public ModelsViewModel(IModelScanner scanner, ISettings settings, ILogService log, IDialogService dialog, IProfileManager profileManager, ILocalizationService loc)
    {
        _scanner = scanner;
        _settings = settings;
        _log = log;
        _dialog = dialog;
        _profileManager = profileManager;
        _loc = loc;
        ModelsDirectory = _settings.ModelsDirectory;
    }

    [RelayCommand]
    internal async Task ScanModels()
    {
        if (string.IsNullOrWhiteSpace(ModelsDirectory) || !Directory.Exists(ModelsDirectory))
        {
            ScanStatus = "Invalid directory";
            return;
        }

        IsScanning = true;
        ScanStatus = "Scanning...";
        Models.Clear();

        try
        {
            var results = await _scanner.ScanDirectoryAsync(ModelsDirectory);

            foreach (var model in results)
                Models.Add(model);

            FilteredCount = Models.Count;
            ScanStatus = $"Found {Models.Count} models";
            _log.Information($"Scan complete: {Models.Count} models", "Models");
        }
        catch (Exception ex)
        {
            ScanStatus = $"Error: {ex.Message}";
            _log.Error(ex, "Scan failed", "Models");
        }
        finally
        {
            IsScanning = false;
        }
    }

    partial void OnSearchFilterChanged(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            FilteredCount = Models.Count;
            return;
        }

        var filter = value.ToLower();
        FilteredCount = Models.Count(m =>
            m.FileName.ToLower().Contains(filter) ||
            m.Architecture.ToLower().Contains(filter) ||
            m.QuantizationTag.ToLower().Contains(filter));
    }

    [RelayCommand]
    async Task SelectDirectory()
    {
        var path = await _dialog.SelectFolderAsync("Select Models Directory", ModelsDirectory);
        if (!string.IsNullOrEmpty(path) && Directory.Exists(path))
        {
            ModelsDirectory = path;
            _settings.ModelsDirectory = path;
            await _settings.SaveAsync();
            ScanStatus = $"Directory: {path}";
            await ScanModels();
        }
    }

    async Task SelectForProfile(GgufModelInfo model)
    {
        if (model == null) return;
        var profile = await _profileManager.GetDefaultProfileAsync();
        if (profile == null)
        {
            _log.Warning("No default profile exists. Create a profile first.", "Models");
            return;
        }
        profile.ModelPath = model.Path;
        await _profileManager.SaveProfileAsync(profile);
        _log.Information($"Selected model for profile: {model.FileName}", "Models");
        ScanStatus = $"Model set: {Path.GetFileName(model.Path)}";
    }

    [RelayCommand]
    async Task UseInServer(GgufModelInfo? model)
    {
        if (model == null) return;
        await SetModelForProfileAsync(model, m => m.ModelPath = model.Path);
        ScanStatus = $"Set as main model: {model.FileName}";
    }

    [RelayCommand]
    async Task UseAsMmproj(GgufModelInfo? model)
    {
        if (model == null) return;
        await SetModelForProfileAsync(model, m => m.MmprojPath = model.Path);
        ScanStatus = $"Set as mmproj: {model.FileName}";
    }

    [RelayCommand]
    async Task UseAsDraft(GgufModelInfo? model)
    {
        if (model == null) return;
        await SetModelForProfileAsync(model, m => m.DraftModelPath = model.Path);
        ScanStatus = $"Set as draft model: {model.FileName}";
    }

    async Task SetModelForProfileAsync(GgufModelInfo model, Action<ServerProfile> setter)
    {
        var profile = await _profileManager.GetDefaultProfileAsync();
        if (profile == null)
        {
            _log.Warning("No default profile exists. Create a profile first.", "Models");
            return;
        }
        setter(profile);
        await _profileManager.SaveProfileAsync(profile);
        _log.Information($"Model set for profile: {model.FileName}", "Models");
    }
}
