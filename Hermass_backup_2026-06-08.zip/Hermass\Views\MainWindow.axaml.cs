using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using Hermass.ViewModels;

namespace Hermass.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    public MainWindow(MainViewModel viewModel) : this()
    {
        this.DataContext = viewModel;
    }

    void InitializeComponent()
    {
        AvaloniaXamlLoader.Load(this);
    }
}
