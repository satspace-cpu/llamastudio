using Hermass.Core.Enums;
using Hermass.Core.Interfaces;
using Hermass.Core.Models;
using System.IO.Compression;
using System.Net.Http.Json;
using System.Text.Json;

namespace Hermass.Infrastructure.Updater;

public class LlamaUpdater : ILlamaUpdater
{
    readonly HttpClient _httpClient;
    readonly ILogService _log;
    readonly ISettings _settings;

    public event EventHandler<double>? DownloadProgress;
    public event EventHandler<string>? StatusMessage;

    static string DefaultDataDir => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "HermassLlamaServer");

    static string DefaultLlamaDir => DefaultDataDir;

    public LlamaUpdater(HttpClient httpClient, ILogService log, ISettings settings)
    {
        _httpClient = httpClient;
        _log = log;
        _settings = settings;
        _httpClient.DefaultRequestHeaders.Add("User-Agent", "Hermass/0.1.0");
        _httpClient.Timeout = TimeSpan.FromMinutes(30);
    }

    async Task<List<LlamaCppRelease>> ILlamaUpdater.FetchReleasesAsync(bool includePrerelease, CancellationToken ct)
    {
        _log.Information("Fetching llama.cpp releases from ggml-org/llama.cpp...", "Updater");

        var releases = await _httpClient.GetFromJsonAsync<List<GithubRelease>>(
            "https://api.github.com/repos/ggml-org/llama.cpp/releases?per_page=30", ct);

        if (releases == null || releases.Count == 0)
            return new();

        var result = new List<LlamaCppRelease>();

        foreach (var rel in releases)
        {
            if (!includePrerelease && rel.Prerelease)
                continue;

            var windowsAssets = FilterWindowsAssets(rel.Assets);

            if (windowsAssets.Count == 0)
                continue;

            result.Add(new LlamaCppRelease
            {
                TagName = rel.TagName,
                Name = rel.Name,
                HtmlUrl = rel.HtmlUrl,
                PublishedAt = rel.PublishedAt,
                IsPrerelease = rel.Prerelease,
                Body = rel.Body,
                Assets = windowsAssets
            });

            if (result.Count >= 30)
                break;
        }

        _log.Information($"Found {result.Count} releases with Windows assets", "Updater");
        return result;
    }

    List<ReleaseAsset> FilterWindowsAssets(List<GithubAsset>? assets)
    {
        if (assets == null)
            return new();

        var result = new List<ReleaseAsset>();

        foreach (var a in assets)
        {
            var name = a.Name.ToLowerInvariant();

            if (name.StartsWith("cudart-"))
                continue;

            if (!name.Contains("-win-") || !name.EndsWith(".zip"))
                continue;

            var asset = ReleaseAsset.ParseAsset(a.Name, a.BrowserDownloadUrl, a.Size, a.UpdatedAt);
            result.Add(asset);
        }

        return result;
    }

    async Task<LlamaCppRelease?> ILlamaUpdater.GetLatestReleaseAsync(bool includePrerelease, CancellationToken ct)
    {
        var releases = await ((ILlamaUpdater)this).FetchReleasesAsync(includePrerelease, ct);
        return releases.FirstOrDefault();
    }

    async Task<string> ILlamaUpdater.DownloadAndExtractAsync(string version, string targetDirectory, CancellationToken ct)
    {
        var releases = await ((ILlamaUpdater)this).FetchReleasesAsync(true, ct);
        var target = releases.FirstOrDefault(r => r.TagName == version);

        if (target == null)
            throw new InvalidOperationException($"Release '{version}' not found");

        var preferred = target.Assets
            .OrderByDescending(a => a.BuildType == BuildType.Cuda12x || a.BuildType == BuildType.Cuda13x ? 2 :
                                   a.BuildType == BuildType.Vulkan ? 1 : 0)
            .FirstOrDefault();

        if (preferred == null)
            throw new InvalidOperationException("No Windows binary found for this release");

        var installDir = Path.Combine(targetDirectory, version);
        if (!Directory.Exists(installDir))
            Directory.CreateDirectory(installDir);

        var ext = preferred.Name.EndsWith(".7z", StringComparison.OrdinalIgnoreCase) ? ".7z" : ".zip";
        var tempFile = Path.Combine(Path.GetTempPath(), $"hermass_{version}{ext}");

        try
        {
            OnStatus($"Downloading {preferred.Name} ({preferred.SizeDisplay})...");
            _log.Information($"Downloading: {preferred.Name}", "Updater");

            // Download to temp file — close stream before extraction
            await DownloadToFileAsync(preferred.BrowserDownloadUrl, tempFile, totalBytesCallback: (total, downloaded) =>
            {
                if (total > 0)
                    OnProgress((double)downloaded / total * 100);
            }, ct);

            if (preferred.BuildType == BuildType.Cuda12x || preferred.BuildType == BuildType.Cuda13x)
            {
                var cudaDllAsset = FindMatchingCudaDll(target, preferred);
                if (cudaDllAsset != null)
                {
                    OnStatus($"Downloading CUDA runtime ({cudaDllAsset.SizeDisplay})...");
                    await DownloadCudaDll(cudaDllAsset, installDir, ct);
                }
            }

            OnStatus("Extracting archive...");
            _log.Information("Extracting archive...", "Updater");

            if (ext == ".zip")
            {
                ExtractZipFlattened(tempFile, installDir);
            }
            else
            {
                Extract7z(tempFile, installDir);
            }

            OnStatus("Download complete!");
            _log.Information($"Installed llama.cpp {version} ({preferred.Description}) to {installDir}", "Updater");
            return installDir;
        }
        finally
        {
            if (File.Exists(tempFile))
                File.Delete(tempFile);
        }
    }

    async Task<string> ILlamaUpdater.DownloadAndExtractAsync(string version, string targetDirectory, ReleaseAsset asset, CancellationToken ct)
    {
        var installDir = Path.Combine(targetDirectory, version);
        if (!Directory.Exists(installDir))
            Directory.CreateDirectory(installDir);

        var ext = asset.Name.EndsWith(".7z", StringComparison.OrdinalIgnoreCase) ? ".7z" : ".zip";
        var tempFile = Path.Combine(Path.GetTempPath(), $"hermass_{version}_{asset.BuildType}{ext}");

        try
        {
            OnStatus($"Downloading {asset.Name} ({asset.SizeDisplay})...");
            _log.Information($"Downloading: {asset.Name}", "Updater");

            // Download to temp file — close stream before extraction
            await DownloadToFileAsync(asset.BrowserDownloadUrl, tempFile, totalBytesCallback: (total, downloaded) =>
            {
                if (total > 0)
                    OnProgress((double)downloaded / total * 100);
            }, ct);

            if (asset.BuildType == BuildType.Cuda12x || asset.BuildType == BuildType.Cuda13x)
            {
                var cudaDllAsset = FindMatchingCudaDll(version, asset);
                if (cudaDllAsset != null)
                {
                    OnStatus($"Downloading CUDA runtime ({cudaDllAsset.SizeDisplay})...");
                    await DownloadCudaDll(cudaDllAsset, installDir, ct);
                }
            }

            OnStatus("Extracting archive...");
            _log.Information("Extracting archive...", "Updater");

            if (ext == ".zip")
            {
                ExtractZipFlattened(tempFile, installDir);
            }
            else
            {
                Extract7z(tempFile, installDir);
            }

            OnStatus("Download complete!");
            _log.Information($"Installed llama.cpp {version} ({asset.Description}) to {installDir}", "Updater");
            return installDir;
        }
        finally
        {
            if (File.Exists(tempFile))
                File.Delete(tempFile);
        }
    }

    ReleaseAsset? FindMatchingCudaDll(string version, ReleaseAsset mainAsset)
    {
        var target = new LlamaCppRelease { TagName = version };
        return FindMatchingCudaDll(target, mainAsset);
    }

    async Task DownloadToFileAsync(string url, string filePath, Action<long, long> totalBytesCallback, CancellationToken ct)
    {
        using var response = await _httpClient.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, ct);
        response.EnsureSuccessStatusCode();

        var totalBytes = response.Content.Headers.ContentLength ?? 0;

        await using var stream = await response.Content.ReadAsStreamAsync(ct);
        await using var file = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None, 81920, true);

        var buffer = new byte[81920];
        long downloaded = 0;
        int read;

        while ((read = await stream.ReadAsync(buffer, ct)) > 0)
        {
            await file.WriteAsync(buffer.AsMemory(0, read), ct);
            downloaded += read;
            totalBytesCallback(totalBytes, downloaded);
        }
    }

    ReleaseAsset? FindMatchingCudaDll(LlamaCppRelease release, ReleaseAsset mainAsset)
    {
        var mainName = mainAsset.Name.ToLowerInvariant();
        string cudaVer;

        if (mainName.Contains("cuda-13") || mainName.Contains("cuda13"))
            cudaVer = "13";
        else if (mainName.Contains("cuda-12.5"))
            cudaVer = "12.5";
        else if (mainName.Contains("cuda-12.4"))
            cudaVer = "12.4";
        else if (mainName.Contains("cuda-12.3"))
            cudaVer = "12.3";
        else if (mainName.Contains("cuda-12.2"))
            cudaVer = "12.2";
        else if (mainName.Contains("cuda-12.1"))
            cudaVer = "12.1";
        else if (mainName.Contains("cuda-12.0"))
            cudaVer = "12.0";
        else
            return null;

        // We need to find cudart from the full release — but our filtered list doesn't have it.
        // Fetch separately:
        try
        {
            var allAssets = _httpClient.GetFromJsonAsync<List<GithubAsset>>(
                $"https://api.github.com/repos/ggml-org/llama.cpp/releases/tags/{release.TagName}",
                CancellationToken.None).Result;

            if (allAssets != null)
            {
                var cudaAsset = allAssets.FirstOrDefault(a =>
                    a.Name.ToLowerInvariant().StartsWith("cudart-") &&
                    a.Name.ToLowerInvariant().Contains(cudaVer) &&
                    a.Name.EndsWith(".zip"));

                if (cudaAsset != null)
                    return ReleaseAsset.ParseAsset(cudaAsset.Name, cudaAsset.BrowserDownloadUrl, cudaAsset.Size, cudaAsset.UpdatedAt);
            }
        }
        catch
        {
            // Ignore — CUDA DLL is optional
        }

        return null;
    }

    async Task DownloadCudaDll(ReleaseAsset cudaAsset, string installDir, CancellationToken ct)
    {
        var tempZip = Path.Combine(Path.GetTempPath(), $"hermass_cuda_{Guid.NewGuid():N}.zip");

        try
        {
            using var response = await _httpClient.GetAsync(cudaAsset.BrowserDownloadUrl, HttpCompletionOption.ResponseHeadersRead, ct);
            response.EnsureSuccessStatusCode();

            using var stream = await response.Content.ReadAsStreamAsync(ct);
            using var file = new FileStream(tempZip, FileMode.Create, FileAccess.Write, FileShare.None, 81920, true);
            await stream.CopyToAsync(file, ct);

            using var archive = new ZipArchive(new FileStream(tempZip, FileMode.Open), ZipArchiveMode.Read);
            foreach (var entry in archive.Entries)
            {
                if (entry.Name.EndsWith(".dll", StringComparison.OrdinalIgnoreCase))
                {
                    entry.ExtractToFile(Path.Combine(installDir, entry.Name), true);
                }
            }
        }
        finally
        {
            if (File.Exists(tempZip))
                File.Delete(tempZip);
        }
    }

    void ExtractZipFlattened(string archivePath, string targetDir)
    {
        using var fs = new FileStream(archivePath, FileMode.Open, FileAccess.Read, FileShare.Read);
        using var archive = new ZipArchive(fs, ZipArchiveMode.Read);

        string? serverEntry = null;
        foreach (var entry in archive.Entries)
        {
            if (entry.Name.Equals("llama-server.exe", StringComparison.OrdinalIgnoreCase))
            {
                serverEntry = entry.FullName;
                break;
            }
        }

        if (serverEntry != null)
        {
            var baseDir = Path.GetDirectoryName(serverEntry);
            foreach (var entry in archive.Entries)
            {
                if (string.IsNullOrEmpty(entry.FullName))
                    continue;

                string targetPath;
                if (!string.IsNullOrEmpty(baseDir) && entry.FullName.StartsWith(baseDir + "/", StringComparison.Ordinal))
                {
                    var relative = entry.FullName.Substring(baseDir.Length + 1);
                    targetPath = Path.Combine(targetDir, relative);
                }
                else
                {
                    targetPath = Path.Combine(targetDir, entry.Name);
                }

                var dir = Path.GetDirectoryName(targetPath);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                if (!string.IsNullOrEmpty(entry.Name))
                    entry.ExtractToFile(targetPath, true);
            }
        }
        else
        {
            archive.ExtractToDirectory(targetDir, true);
        }
    }

    void ExtractZip(string archivePath, string targetDir)
    {
        using var fs = new FileStream(archivePath, FileMode.Open, FileAccess.Read, FileShare.Read);
        using var archive = new ZipArchive(fs, ZipArchiveMode.Read);
        archive.ExtractToDirectory(targetDir, true);
    }

    async Task Download7zExtractorAsync(string targetPath)
    {
        using var response = await _httpClient.GetAsync("https://www.7-zip.org/a/7zr.exe");
        response.EnsureSuccessStatusCode();
        using var stream = await response.Content.ReadAsStreamAsync();
        using var file = new FileStream(targetPath, FileMode.Create, FileAccess.Write, FileShare.None);
        await stream.CopyToAsync(file);
    }

    void Extract7z(string archivePath, string targetDir)
    {
        var tempExe = Path.Combine(Path.GetTempPath(), "hermass_7z.exe");

        if (!File.Exists(tempExe))
        {
            var downloadTask = Download7zExtractorAsync(tempExe);
            downloadTask.Wait();
        }

        var psi = new System.Diagnostics.ProcessStartInfo
        {
            FileName = tempExe,
            Arguments = $"x \"{archivePath}\" -o\"{targetDir}\" -y",
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };

        using var proc = System.Diagnostics.Process.Start(psi);
        proc?.WaitForExit();
    }

    Task<List<string>> ILlamaUpdater.GetInstalledVersionsAsync(string installDirectory)
    {
        if (!Directory.Exists(installDirectory))
            return Task.FromResult(new List<string>());

        var dirs = Directory.GetDirectories(installDirectory)
            .Select(d => Path.GetFileName(d)!)
            .Where(n => n.StartsWith("b") || n.StartsWith("v") || n.StartsWith("B") || n.StartsWith("V"))
            .OrderByDescending(n => n)
            .ToList();

        return Task.FromResult(dirs!);
    }

    bool ILlamaUpdater.IsVersionInstalledAsync(string installDirectory, string version)
    {
        var path = Path.Combine(installDirectory, version);
        return Directory.Exists(path) && File.Exists(Path.Combine(path, "llama-server.exe"));
    }

    Task ILlamaUpdater.UninstallVersionAsync(string installDirectory, string version)
    {
        var path = Path.Combine(installDirectory, version);
        if (Directory.Exists(path))
        {
            Directory.Delete(path, true);
            _log.Information($"Uninstalled version {version}", "Updater");
        }
        return Task.CompletedTask;
    }

    void OnProgress(double value) => DownloadProgress?.Invoke(this, value);
    void OnStatus(string message) => StatusMessage?.Invoke(this, message);

    class GithubRelease
    {
        [System.Text.Json.Serialization.JsonPropertyName("tag_name")]
        public string TagName { get; set; } = string.Empty;

        [System.Text.Json.Serialization.JsonPropertyName("name")]
        public string Name { get; set; } = string.Empty;

        [System.Text.Json.Serialization.JsonPropertyName("html_url")]
        public string HtmlUrl { get; set; } = string.Empty;

        [System.Text.Json.Serialization.JsonPropertyName("published_at")]
        public DateTime PublishedAt { get; set; }

        [System.Text.Json.Serialization.JsonPropertyName("prerelease")]
        public bool Prerelease { get; set; }

        [System.Text.Json.Serialization.JsonPropertyName("body")]
        public string Body { get; set; } = string.Empty;

        [System.Text.Json.Serialization.JsonPropertyName("assets")]
        public List<GithubAsset>? Assets { get; set; }
    }

    class GithubAsset
    {
        [System.Text.Json.Serialization.JsonPropertyName("name")]
        public string Name { get; set; } = string.Empty;

        [System.Text.Json.Serialization.JsonPropertyName("browser_download_url")]
        public string BrowserDownloadUrl { get; set; } = string.Empty;

        [System.Text.Json.Serialization.JsonPropertyName("size")]
        public long Size { get; set; }

        [System.Text.Json.Serialization.JsonPropertyName("updated_at")]
        public DateTime UpdatedAt { get; set; }
    }
}
