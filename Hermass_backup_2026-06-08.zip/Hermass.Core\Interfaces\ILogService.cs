namespace Hermass.Core.Interfaces;

public interface ILogService
{
    IObservable<Models.LogEntry> LogStream { get; }
    void Debug(string message, string source = "App");
    void Information(string message, string source = "App");
    void Warning(string message, string source = "App");
    void Error(string message, string source = "App");
    void Error(Exception exception, string message, string source = "App");
    Task ExportLogsAsync(string path);
    Task ClearLogsAsync();
    List<Models.LogEntry> GetRecentLogs(int count = 100);
}
